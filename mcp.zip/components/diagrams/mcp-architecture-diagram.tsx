"use client";

import { useEffect, useState } from "react";

export function MCPArchitectureDiagram() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setIsVisible(true), 100);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="w-full h-full flex items-center justify-center p-2">
      <svg
        viewBox="0 0 900 300"
        className="w-full max-w-4xl h-auto"
        style={{ maxHeight: "100%" }}
      >
        <defs>
          <linearGradient id="hostGradient" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#3b5bdb" />
            <stop offset="100%" stopColor="#2b4acb" />
          </linearGradient>
          <linearGradient id="clientGradient" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#4c6ef5" />
            <stop offset="100%" stopColor="#3b5bdb" />
          </linearGradient>
          <linearGradient id="serverGradient" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#5c7cfa" />
            <stop offset="100%" stopColor="#4c6ef5" />
          </linearGradient>
          <marker
            id="archArrowRight"
            markerWidth="10"
            markerHeight="10"
            refX="9"
            refY="3"
            orient="auto"
            markerUnits="strokeWidth"
          >
            <path d="M0,0 L0,6 L9,3 z" fill="#3b5bdb" />
          </marker>
          <filter id="archShadow" x="-20%" y="-20%" width="140%" height="140%">
            <feDropShadow dx="0" dy="4" stdDeviation="6" floodColor="#1a1a2e" floodOpacity="0.15" />
          </filter>
          <filter id="archPulse" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="3" result="coloredBlur" />
            <feMerge>
              <feMergeNode in="coloredBlur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        {/* Background grid */}
        <pattern id="archGrid" width="40" height="40" patternUnits="userSpaceOnUse">
          <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#e5e7eb" strokeWidth="0.5" opacity="0.5" />
        </pattern>
        <rect width="100%" height="100%" fill="url(#archGrid)" opacity="0.3" />

        {/* ── MCP HOST ── */}
        <g
          style={{
            opacity: isVisible ? 1 : 0,
            transition: "opacity 0.7s ease 0ms",
          }}
        >
          <rect x="50" y="80" width="160" height="140" rx="12" fill="url(#hostGradient)" filter="url(#archShadow)" />
          <circle cx="130" cy="125" r="28" fill="white" fillOpacity="0.15" />
          {/* User icon */}
          <circle cx="130" cy="114" r="10" fill="white" />
          <path d="M110 148c0-11 9-20 20-20s20 9 20 20" fill="none" stroke="white" strokeWidth="3" strokeLinecap="round" />
          <text x="130" y="178" textAnchor="middle" fill="white" fontSize="15" fontWeight="600" fontFamily="system-ui,sans-serif">MCP Host</text>
          <text x="130" y="196" textAnchor="middle" fill="white" fillOpacity="0.8" fontSize="11" fontFamily="system-ui,sans-serif">AI Application</text>
        </g>

        {/* ── MCP CLIENT 1 ── */}
        <g
          style={{
            opacity: isVisible ? 1 : 0,
            transition: "opacity 0.7s ease 200ms",
          }}
        >
          <rect x="370" y="45" width="160" height="95" rx="12" fill="url(#clientGradient)" filter="url(#archShadow)" />
          <circle cx="450" cy="75" r="20" fill="white" fillOpacity="0.15" />
          {/* Bridge icon */}
          <g transform="translate(438,63)" stroke="white" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round">
            <path d="M0 12h24M0 12l5-5M0 12l5 5M24 12l-5-5M24 12l-5 5" />
          </g>
          <text x="450" y="115" textAnchor="middle" fill="white" fontSize="13" fontWeight="600" fontFamily="system-ui,sans-serif">MCP Client</text>
          <text x="450" y="130" textAnchor="middle" fill="white" fillOpacity="0.8" fontSize="10" fontFamily="system-ui,sans-serif">Protocol Bridge</text>
        </g>

        {/* ── MCP CLIENT 2 ── */}
        <g
          style={{
            opacity: isVisible ? 0.85 : 0,
            transition: "opacity 0.7s ease 200ms",
          }}
        >
          <rect x="370" y="162" width="160" height="95" rx="12" fill="url(#clientGradient)" filter="url(#archShadow)" />
          <circle cx="450" cy="192" r="20" fill="white" fillOpacity="0.15" />
          <g transform="translate(438,180)" stroke="white" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round">
            <path d="M0 12h24M0 12l5-5M0 12l5 5M24 12l-5-5M24 12l-5 5" />
          </g>
          <text x="450" y="232" textAnchor="middle" fill="white" fontSize="13" fontWeight="600" fontFamily="system-ui,sans-serif">MCP Client</text>
          <text x="450" y="247" textAnchor="middle" fill="white" fillOpacity="0.8" fontSize="10" fontFamily="system-ui,sans-serif">Protocol Bridge</text>
        </g>

        {/* ── MCP SERVER 1 ── */}
        <g
          style={{
            opacity: isVisible ? 1 : 0,
            transition: "opacity 0.7s ease 400ms",
          }}
        >
          <rect x="690" y="45" width="160" height="95" rx="12" fill="url(#serverGradient)" filter="url(#archShadow)" />
          <circle cx="770" cy="75" r="20" fill="white" fillOpacity="0.15" />
          {/* Wrench/tool icon as pure SVG paths */}
          <g transform="translate(758,63)" stroke="white" strokeWidth="1.8" fill="none" strokeLinecap="round" strokeLinejoin="round">
            <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z" />
          </g>
          <text x="770" y="115" textAnchor="middle" fill="white" fontSize="13" fontWeight="600" fontFamily="system-ui,sans-serif">MCP Server</text>
          <text x="770" y="130" textAnchor="middle" fill="white" fillOpacity="0.8" fontSize="10" fontFamily="system-ui,sans-serif">Tools &amp; Resources</text>
        </g>

        {/* ── MCP SERVER 2 ── */}
        <g
          style={{
            opacity: isVisible ? 0.85 : 0,
            transition: "opacity 0.7s ease 400ms",
          }}
        >
          <rect x="690" y="162" width="160" height="95" rx="12" fill="url(#serverGradient)" filter="url(#archShadow)" />
          <circle cx="770" cy="192" r="20" fill="white" fillOpacity="0.15" />
          <g transform="translate(758,180)" stroke="white" strokeWidth="1.8" fill="none" strokeLinecap="round" strokeLinejoin="round">
            <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z" />
          </g>
          <text x="770" y="232" textAnchor="middle" fill="white" fontSize="13" fontWeight="600" fontFamily="system-ui,sans-serif">MCP Server</text>
          <text x="770" y="247" textAnchor="middle" fill="white" fillOpacity="0.8" fontSize="10" fontFamily="system-ui,sans-serif">Tools &amp; Resources</text>
        </g>

        {/* ── CONNECTION LINES: Host → Clients ── */}
        <g
          style={{
            opacity: isVisible ? 1 : 0,
            transition: "opacity 0.7s ease 600ms",
          }}
        >
          {/* Host → Client 1 */}
          <line x1="210" y1="118" x2="365" y2="92" stroke="#3b5bdb" strokeWidth="2.5" strokeDasharray="8,4" markerEnd="url(#archArrowRight)">
            <animate attributeName="stroke-dashoffset" values="0;-24" dur="1.5s" repeatCount="indefinite" />
          </line>
          <line x1="365" y1="82" x2="210" y2="108" stroke="#5c7cfa" strokeWidth="1.5" strokeDasharray="8,4" opacity="0.6">
            <animate attributeName="stroke-dashoffset" values="0;24" dur="1.5s" repeatCount="indefinite" />
          </line>
          {/* Host → Client 2 */}
          <line x1="210" y1="182" x2="365" y2="210" stroke="#3b5bdb" strokeWidth="2.5" strokeDasharray="8,4" markerEnd="url(#archArrowRight)">
            <animate attributeName="stroke-dashoffset" values="0;-24" dur="1.8s" repeatCount="indefinite" />
          </line>
          <line x1="365" y1="200" x2="210" y2="172" stroke="#5c7cfa" strokeWidth="1.5" strokeDasharray="8,4" opacity="0.6">
            <animate attributeName="stroke-dashoffset" values="0;24" dur="1.8s" repeatCount="indefinite" />
          </line>
        </g>

        {/* ── CONNECTION LINES: Clients → Servers ── */}
        <g
          style={{
            opacity: isVisible ? 1 : 0,
            transition: "opacity 0.7s ease 800ms",
          }}
        >
          {/* Client 1 → Server 1 */}
          <line x1="530" y1="92" x2="685" y2="92" stroke="#3b5bdb" strokeWidth="2.5" strokeDasharray="8,4" markerEnd="url(#archArrowRight)">
            <animate attributeName="stroke-dashoffset" values="0;-24" dur="1.2s" repeatCount="indefinite" />
          </line>
          <line x1="685" y1="82" x2="530" y2="82" stroke="#5c7cfa" strokeWidth="1.5" strokeDasharray="8,4" opacity="0.6">
            <animate attributeName="stroke-dashoffset" values="0;24" dur="1.2s" repeatCount="indefinite" />
          </line>
          {/* Client 2 → Server 2 */}
          <line x1="530" y1="210" x2="685" y2="210" stroke="#3b5bdb" strokeWidth="2.5" strokeDasharray="8,4" markerEnd="url(#archArrowRight)">
            <animate attributeName="stroke-dashoffset" values="0;-24" dur="1.4s" repeatCount="indefinite" />
          </line>
          <line x1="685" y1="200" x2="530" y2="200" stroke="#5c7cfa" strokeWidth="1.5" strokeDasharray="8,4" opacity="0.6">
            <animate attributeName="stroke-dashoffset" values="0;24" dur="1.4s" repeatCount="indefinite" />
          </line>
        </g>

        {/* ── RELATIONSHIP LABELS ── */}
        <g
          style={{
            opacity: isVisible ? 1 : 0,
            transition: "opacity 0.7s ease 1000ms",
          }}
        >
          <rect x="263" y="140" width="45" height="22" rx="11" fill="#f0f4ff" stroke="#3b5bdb" strokeWidth="1.5" />
          <text x="285" y="155" textAnchor="middle" fill="#3b5bdb" fontSize="11" fontWeight="600" fontFamily="system-ui,sans-serif">1 : N</text>
          <rect x="582" y="140" width="42" height="22" rx="11" fill="#f0f4ff" stroke="#3b5bdb" strokeWidth="1.5" />
          <text x="603" y="155" textAnchor="middle" fill="#3b5bdb" fontSize="11" fontWeight="600" fontFamily="system-ui,sans-serif">1 : 1</text>
        </g>

        {/* ── PULSE RING ON HOST ── */}
        <g
          style={{
            opacity: isVisible ? 1 : 0,
            transition: "opacity 0.7s ease 1200ms",
          }}
        >
          <circle cx="130" cy="150" r="35" fill="none" stroke="#3b5bdb" strokeWidth="1" opacity="0.3">
            <animate attributeName="r" values="28;50;28" dur="2s" repeatCount="indefinite" />
            <animate attributeName="opacity" values="0.4;0;0.4" dur="2s" repeatCount="indefinite" />
          </circle>
        </g>
      </svg>
    </div>
  );
}
