"use client";

import { useEffect, useState } from "react";

export function BrainInABoxVisual() {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  return (
    <div className="relative w-full h-full flex items-center justify-center">
      <svg
        viewBox="0 0 320 240"
        className="w-full h-full max-w-[320px] max-h-[240px]"
        style={{ overflow: "visible" }}
      >
        <defs>
          {/* Gradient for the box */}
          <linearGradient id="boxGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="oklch(0.7 0.02 250)" stopOpacity="0.3" />
            <stop offset="100%" stopColor="oklch(0.5 0.03 250)" stopOpacity="0.2" />
          </linearGradient>

          {/* Gradient for brain */}
          <linearGradient id="brainGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="oklch(0.55 0.2 260)" />
            <stop offset="100%" stopColor="oklch(0.4 0.22 260)" />
          </linearGradient>

          {/* Glow filter for brain */}
          <filter id="brainGlow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="3" result="coloredBlur" />
            <feMerge>
              <feMergeNode in="coloredBlur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>

          {/* Bounce animation paths for each icon */}
          <style>
            {`
              @keyframes float1 {
                0%, 100% { transform: translate(0, 0); }
                50% { transform: translate(-3px, -5px); }
              }
              @keyframes float2 {
                0%, 100% { transform: translate(0, 0); }
                50% { transform: translate(5px, -3px); }
              }
              @keyframes float3 {
                0%, 100% { transform: translate(0, 0); }
                50% { transform: translate(-4px, 4px); }
              }
              @keyframes float4 {
                0%, 100% { transform: translate(0, 0); }
                50% { transform: translate(3px, 5px); }
              }
              @keyframes bounce1 {
                0%, 100% { transform: translate(0, 0); opacity: 0.7; }
                40% { transform: translate(20px, 12px); opacity: 1; }
                50% { transform: translate(15px, 8px); opacity: 0.9; }
                60% { transform: translate(20px, 12px); opacity: 0.85; }
                70% { transform: translate(0, 0); opacity: 0.7; }
              }
              @keyframes bounce2 {
                0%, 100% { transform: translate(0, 0); opacity: 0.7; }
                40% { transform: translate(-18px, 10px); opacity: 1; }
                50% { transform: translate(-12px, 6px); opacity: 0.9; }
                60% { transform: translate(-18px, 10px); opacity: 0.85; }
                70% { transform: translate(0, 0); opacity: 0.7; }
              }
              @keyframes bounce3 {
                0%, 100% { transform: translate(0, 0); opacity: 0.7; }
                40% { transform: translate(15px, -15px); opacity: 1; }
                50% { transform: translate(10px, -10px); opacity: 0.9; }
                60% { transform: translate(15px, -15px); opacity: 0.85; }
                70% { transform: translate(0, 0); opacity: 0.7; }
              }
              @keyframes bounce4 {
                0%, 100% { transform: translate(0, 0); opacity: 0.7; }
                40% { transform: translate(-15px, -12px); opacity: 1; }
                50% { transform: translate(-10px, -8px); opacity: 0.9; }
                60% { transform: translate(-15px, -12px); opacity: 0.85; }
                70% { transform: translate(0, 0); opacity: 0.7; }
              }
              @keyframes pulse {
                0%, 100% { opacity: 0.15; }
                50% { opacity: 0.25; }
              }
              @keyframes boxPulse {
                0%, 100% { stroke-opacity: 0.4; }
                50% { stroke-opacity: 0.7; }
              }
              @keyframes connectionAttempt1 {
                0%, 70%, 100% { opacity: 0; stroke-dashoffset: 40; }
                35%, 55% { opacity: 0.6; stroke-dashoffset: 0; }
              }
              @keyframes connectionAttempt2 {
                0%, 70%, 100% { opacity: 0; stroke-dashoffset: 40; }
                35%, 55% { opacity: 0.6; stroke-dashoffset: 0; }
              }
              @keyframes connectionAttempt3 {
                0%, 70%, 100% { opacity: 0; stroke-dashoffset: 40; }
                35%, 55% { opacity: 0.6; stroke-dashoffset: 0; }
              }
              @keyframes connectionAttempt4 {
                0%, 70%, 100% { opacity: 0; stroke-dashoffset: 40; }
                35%, 55% { opacity: 0.6; stroke-dashoffset: 0; }
              }
              @keyframes rejectFlash {
                0%, 45%, 65%, 100% { opacity: 0; }
                50%, 60% { opacity: 0.8; }
              }
              .icon-group-1 { animation: bounce1 4s ease-in-out infinite; }
              .icon-group-2 { animation: bounce2 4s ease-in-out infinite 0.5s; }
              .icon-group-3 { animation: bounce3 4s ease-in-out infinite 1s; }
              .icon-group-4 { animation: bounce4 4s ease-in-out infinite 1.5s; }
              .box-glow { animation: pulse 3s ease-in-out infinite; }
              .box-stroke { animation: boxPulse 3s ease-in-out infinite; }
              .connection-line-1 { animation: connectionAttempt1 4s ease-in-out infinite; }
              .connection-line-2 { animation: connectionAttempt2 4s ease-in-out infinite 0.5s; }
              .connection-line-3 { animation: connectionAttempt3 4s ease-in-out infinite 1s; }
              .connection-line-4 { animation: connectionAttempt4 4s ease-in-out infinite 1.5s; }
              .reject-x-1 { animation: rejectFlash 4s ease-in-out infinite; }
              .reject-x-2 { animation: rejectFlash 4s ease-in-out infinite 0.5s; }
              .reject-x-3 { animation: rejectFlash 4s ease-in-out infinite 1s; }
              .reject-x-4 { animation: rejectFlash 4s ease-in-out infinite 1.5s; }
            `}
          </style>
        </defs>

        {/* Background subtle grid pattern */}
        <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
          <path
            d="M 20 0 L 0 0 0 20"
            fill="none"
            stroke="oklch(0.5 0.03 250)"
            strokeWidth="0.3"
            opacity="0.3"
          />
        </pattern>
        <rect width="320" height="240" fill="url(#grid)" opacity="0.5" />

        {/* The Box - semi-transparent barrier */}
        <g transform="translate(110, 60)">
          {/* Box glow effect */}
          <rect
            x="-5"
            y="-5"
            width="110"
            height="110"
            rx="8"
            fill="oklch(0.45 0.2 260)"
            className="box-glow"
          />

          {/* Box fill */}
          <rect
            x="0"
            y="0"
            width="100"
            height="100"
            rx="6"
            fill="url(#boxGradient)"
            stroke="oklch(0.5 0.1 250)"
            strokeWidth="2"
            className="box-stroke"
          />

          {/* Box inner highlight */}
          <rect
            x="4"
            y="4"
            width="92"
            height="92"
            rx="4"
            fill="none"
            stroke="oklch(0.8 0.02 250)"
            strokeWidth="0.5"
            opacity="0.3"
          />
        </g>

        {/* Brain Icon - centered in the box */}
        <g transform="translate(160, 110)" filter="url(#brainGlow)">
          {/* Brain SVG - stylized brain shape */}
          <g transform="translate(-24, -24) scale(1.2)">
            {/* Left hemisphere */}
            <path
              d="M20 8c-4 0-7 3-7 7 0 2 0.5 3.5 1.5 4.5-1 0.5-2 1.5-2.5 3-0.5 1.5-0.5 3 0 4.5 0.5 1.5 1.5 2.5 3 3 0.5 2 2 3.5 4 4 2 0.5 4 0 5.5-1.5"
              fill="url(#brainGradient)"
              stroke="oklch(0.35 0.22 260)"
              strokeWidth="1"
              strokeLinecap="round"
            />
            {/* Right hemisphere */}
            <path
              d="M20 8c4 0 7 3 7 7 0 2-0.5 3.5-1.5 4.5 1 0.5 2 1.5 2.5 3 0.5 1.5 0.5 3 0 4.5-0.5 1.5-1.5 2.5-3 3-0.5 2-2 3.5-4 4-2 0.5-4 0-5.5-1.5"
              fill="url(#brainGradient)"
              stroke="oklch(0.35 0.22 260)"
              strokeWidth="1"
              strokeLinecap="round"
            />
            {/* Brain folds/details */}
            <path
              d="M16 12c2 1 4 1 6 0M14 18c3 1 6 1 9 0M15 24c2.5 0.5 5 0.5 7.5 0"
              fill="none"
              stroke="oklch(0.35 0.22 260)"
              strokeWidth="0.8"
              strokeLinecap="round"
              opacity="0.7"
            />
          </g>
        </g>

        {/* External Icons with bounce animations */}

        {/* Calendar Icon - Top Left */}
        <g className={mounted ? "icon-group-1" : ""} opacity="0.7">
          <g transform="translate(35, 45)">
            {/* Connection attempt line */}
            <line
              x1="28"
              y1="20"
              x2="75"
              y2="35"
              stroke="oklch(0.55 0.15 200)"
              strokeWidth="2"
              strokeDasharray="4 2"
              className={mounted ? "connection-line-1" : ""}
              opacity="0"
            />
            {/* Reject X mark */}
            <g transform="translate(55, 25)" className={mounted ? "reject-x-1" : ""} opacity="0">
              <line x1="-4" y1="-4" x2="4" y2="4" stroke="oklch(0.577 0.245 27.325)" strokeWidth="2" />
              <line x1="4" y1="-4" x2="-4" y2="4" stroke="oklch(0.577 0.245 27.325)" strokeWidth="2" />
            </g>
            {/* Icon background */}
            <rect
              x="0"
              y="0"
              width="32"
              height="32"
              rx="6"
              fill="oklch(0.95 0.02 200)"
              stroke="oklch(0.55 0.15 200)"
              strokeWidth="1.5"
            />
            {/* Calendar details */}
            <rect x="4" y="8" width="24" height="20" rx="2" fill="none" stroke="oklch(0.55 0.15 200)" strokeWidth="1.2" />
            <line x1="4" y1="14" x2="28" y2="14" stroke="oklch(0.55 0.15 200)" strokeWidth="1" />
            <line x1="10" y1="4" x2="10" y2="10" stroke="oklch(0.55 0.15 200)" strokeWidth="1.5" strokeLinecap="round" />
            <line x1="22" y1="4" x2="22" y2="10" stroke="oklch(0.55 0.15 200)" strokeWidth="1.5" strokeLinecap="round" />
            <rect x="8" y="18" width="4" height="4" rx="0.5" fill="oklch(0.55 0.15 200)" />
            <rect x="14" y="18" width="4" height="4" rx="0.5" fill="oklch(0.55 0.15 200)" />
            <rect x="20" y="18" width="4" height="4" rx="0.5" fill="oklch(0.55 0.15 200)" />
          </g>
        </g>

        {/* Database Icon - Top Right */}
        <g className={mounted ? "icon-group-2" : ""} opacity="0.7">
          <g transform="translate(255, 50)">
            {/* Connection attempt line */}
            <line
              x1="4"
              y1="20"
              x2="-40"
              y2="35"
              stroke="oklch(0.6 0.12 170)"
              strokeWidth="2"
              strokeDasharray="4 2"
              className={mounted ? "connection-line-2" : ""}
              opacity="0"
            />
            {/* Reject X mark */}
            <g transform="translate(-22, 25)" className={mounted ? "reject-x-2" : ""} opacity="0">
              <line x1="-4" y1="-4" x2="4" y2="4" stroke="oklch(0.577 0.245 27.325)" strokeWidth="2" />
              <line x1="4" y1="-4" x2="-4" y2="4" stroke="oklch(0.577 0.245 27.325)" strokeWidth="2" />
            </g>
            {/* Icon background */}
            <rect
              x="0"
              y="0"
              width="32"
              height="32"
              rx="6"
              fill="oklch(0.95 0.02 170)"
              stroke="oklch(0.6 0.12 170)"
              strokeWidth="1.5"
            />
            {/* Database cylinder */}
            <ellipse cx="16" cy="10" rx="10" ry="4" fill="none" stroke="oklch(0.6 0.12 170)" strokeWidth="1.2" />
            <path d="M6 10v12c0 2.2 4.5 4 10 4s10-1.8 10-4V10" fill="none" stroke="oklch(0.6 0.12 170)" strokeWidth="1.2" />
            <ellipse cx="16" cy="16" rx="10" ry="4" fill="none" stroke="oklch(0.6 0.12 170)" strokeWidth="0.8" opacity="0.5" />
          </g>
        </g>

        {/* API Icon - Bottom Left */}
        <g className={mounted ? "icon-group-3" : ""} opacity="0.7">
          <g transform="translate(40, 165)">
            {/* Connection attempt line */}
            <line
              x1="28"
              y1="10"
              x2="70"
              y2="-5"
              stroke="oklch(0.5 0.15 280)"
              strokeWidth="2"
              strokeDasharray="4 2"
              className={mounted ? "connection-line-3" : ""}
              opacity="0"
            />
            {/* Reject X mark */}
            <g transform="translate(52, 0)" className={mounted ? "reject-x-3" : ""} opacity="0">
              <line x1="-4" y1="-4" x2="4" y2="4" stroke="oklch(0.577 0.245 27.325)" strokeWidth="2" />
              <line x1="4" y1="-4" x2="-4" y2="4" stroke="oklch(0.577 0.245 27.325)" strokeWidth="2" />
            </g>
            {/* Icon background */}
            <rect
              x="0"
              y="0"
              width="32"
              height="32"
              rx="6"
              fill="oklch(0.95 0.02 280)"
              stroke="oklch(0.5 0.15 280)"
              strokeWidth="1.5"
            />
            {/* API brackets */}
            <text
              x="16"
              y="22"
              textAnchor="middle"
              fontFamily="monospace"
              fontSize="11"
              fontWeight="bold"
              fill="oklch(0.5 0.15 280)"
            >
              {"{ }"}
            </text>
          </g>
        </g>

        {/* Cloud/File Icon - Bottom Right */}
        <g className={mounted ? "icon-group-4" : ""} opacity="0.7">
          <g transform="translate(250, 160)">
            {/* Connection attempt line */}
            <line
              x1="4"
              y1="10"
              x2="-35"
              y2="-5"
              stroke="oklch(0.55 0.1 230)"
              strokeWidth="2"
              strokeDasharray="4 2"
              className={mounted ? "connection-line-4" : ""}
              opacity="0"
            />
            {/* Reject X mark */}
            <g transform="translate(-18, 0)" className={mounted ? "reject-x-4" : ""} opacity="0">
              <line x1="-4" y1="-4" x2="4" y2="4" stroke="oklch(0.577 0.245 27.325)" strokeWidth="2" />
              <line x1="4" y1="-4" x2="-4" y2="4" stroke="oklch(0.577 0.245 27.325)" strokeWidth="2" />
            </g>
            {/* Icon background */}
            <rect
              x="0"
              y="0"
              width="32"
              height="32"
              rx="6"
              fill="oklch(0.95 0.02 230)"
              stroke="oklch(0.55 0.1 230)"
              strokeWidth="1.5"
            />
            {/* Cloud shape */}
            <path
              d="M10 22h12c2.5 0 4.5-2 4.5-4.5 0-2-1.3-3.7-3.2-4.3 0-0.1 0-0.1 0-0.2 0-3-2.5-5.5-5.5-5.5-2.5 0-4.6 1.7-5.3 4-0.3 0-0.7-0.1-1-0.1-2 0-3.5 1.6-3.5 3.5 0 0.5 0.1 0.9 0.2 1.3C7 17 6 18.5 6 20.2 6 21.2 7.8 22 10 22z"
              fill="none"
              stroke="oklch(0.55 0.1 230)"
              strokeWidth="1.2"
            />
          </g>
        </g>

        {/* "Isolated" indicator text */}
        <text
          x="160"
          y="225"
          textAnchor="middle"
          fontSize="10"
          fontFamily="var(--font-sans)"
          fill="oklch(0.5 0.03 250)"
          opacity="0.6"
        >
          LLM Isolated from External Systems
        </text>
      </svg>
    </div>
  );
}
