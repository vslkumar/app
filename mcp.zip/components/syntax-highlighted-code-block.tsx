"use client";

import { useState } from "react";
import { Prism as SyntaxHighlighter } from "react-syntax-highlighter";
import { Check, Copy } from "lucide-react";

const pythonCode = `from fastmcp import FastMCP

# Initialize MCP server
mcp = FastMCP("Demo")

@mcp.tool()
def get_weather(city: str) -> str:
    """Get current weather for a city"""
    # Your API logic here
    return f"Weather in {city}: Sunny, 72°F"

# Run server
if __name__ == "__main__":
    mcp.run(transport="stdio")`;

// Custom theme matching the royal blue corporate aesthetic
const customTheme: { [key: string]: React.CSSProperties } = {
  'code[class*="language-"]': {
    color: "#1e293b",
    fontFamily: "var(--font-mono), 'JetBrains Mono', monospace",
    fontSize: "0.8rem",
    lineHeight: "1.5",
    textAlign: "left",
    whiteSpace: "pre",
    wordSpacing: "normal",
    wordBreak: "normal",
    wordWrap: "normal",
    tabSize: 4,
    hyphens: "none",
  },
  'pre[class*="language-"]': {
    color: "#1e293b",
    fontFamily: "var(--font-mono), 'JetBrains Mono', monospace",
    fontSize: "0.8rem",
    lineHeight: "1.5",
    textAlign: "left",
    whiteSpace: "pre",
    wordSpacing: "normal",
    wordBreak: "normal",
    wordWrap: "normal",
    tabSize: 4,
    hyphens: "none",
    padding: "0.75rem 1rem",
    margin: 0,
    overflow: "auto",
    background: "transparent",
  },
  comment: { color: "#64748b", fontStyle: "italic" },
  prolog: { color: "#64748b" },
  doctype: { color: "#64748b" },
  cdata: { color: "#64748b" },
  punctuation: { color: "#475569" },
  property: { color: "#0369a1" },
  tag: { color: "#0369a1" },
  boolean: { color: "#2563eb" },
  number: { color: "#2563eb" },
  constant: { color: "#2563eb" },
  symbol: { color: "#2563eb" },
  deleted: { color: "#dc2626" },
  selector: { color: "#059669" },
  "attr-name": { color: "#059669" },
  string: { color: "#059669" },
  char: { color: "#059669" },
  builtin: { color: "#7c3aed" },
  inserted: { color: "#059669" },
  operator: { color: "#475569" },
  entity: { color: "#475569", cursor: "help" },
  url: { color: "#475569" },
  ".language-css .token.string": { color: "#475569" },
  ".style .token.string": { color: "#475569" },
  variable: { color: "#475569" },
  atrule: { color: "#2563eb", fontWeight: "600" },
  "attr-value": { color: "#2563eb" },
  keyword: { color: "#2563eb", fontWeight: "600" },
  function: { color: "#7c3aed" },
  "class-name": { color: "#0369a1", fontWeight: "600" },
  regex: { color: "#f97316" },
  important: { color: "#f97316", fontWeight: "bold" },
  decorator: { color: "#1d4ed8", fontWeight: "700" },
  "decorator-function": { color: "#1d4ed8", fontWeight: "700" },
  "function-variable": { color: "#7c3aed" },
  "triple-quoted-string": { color: "#059669", fontStyle: "italic" },
};

export function SyntaxHighlightedCodeBlock() {
  const [copied, setCopied] = useState(false);
  const [isHovered, setIsHovered] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(pythonCode);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error("Failed to copy:", err);
    }
  };

  return (
    <div
      className="relative w-full"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Editor Header */}
      <div className="flex items-center justify-between px-3 py-2 bg-secondary/80 rounded-t-lg border border-border border-b-0">
        <div className="flex items-center gap-2">
          <div className="flex gap-1.5">
            <div className="w-2.5 h-2.5 rounded-full bg-red-400/80" />
            <div className="w-2.5 h-2.5 rounded-full bg-yellow-400/80" />
            <div className="w-2.5 h-2.5 rounded-full bg-green-400/80" />
          </div>
          <span className="ml-2 text-xs font-medium text-muted-foreground font-mono">
            mcp_server.py
          </span>
        </div>

        {/* Copy button */}
        <button
          onClick={handleCopy}
          className={`
            flex items-center gap-1 px-2 py-1 rounded-md text-xs font-medium
            transition-all duration-200 cursor-pointer
            ${
              copied
                ? "bg-green-100 text-green-700 border border-green-200"
                : "bg-background/60 text-muted-foreground hover:bg-primary hover:text-primary-foreground border border-border hover:border-primary"
            }
            ${isHovered || copied ? "opacity-100" : "opacity-0"}
          `}
          aria-label={copied ? "Copied!" : "Copy code"}
        >
          {copied ? (
            <>
              <Check className="w-3 h-3" />
              <span>Copied!</span>
            </>
          ) : (
            <>
              <Copy className="w-3 h-3" />
              <span>Copy</span>
            </>
          )}
        </button>
      </div>

      {/* Code Block */}
      <div className="bg-muted/40 rounded-b-lg border border-border border-t-0 overflow-hidden">
        <SyntaxHighlighter
          language="python"
          style={customTheme}
          showLineNumbers
          lineNumberStyle={{
            minWidth: "2em",
            paddingRight: "0.75em",
            color: "#94a3b8",
            textAlign: "right",
            userSelect: "none",
            fontSize: "0.75rem",
          }}
          customStyle={{
            margin: 0,
            padding: "0.75rem 0",
            background: "transparent",
            fontSize: "0.8rem",
          }}
          codeTagProps={{
            style: {
              fontFamily: "var(--font-mono), 'JetBrains Mono', monospace",
            },
          }}
        >
          {pythonCode}
        </SyntaxHighlighter>
      </div>
    </div>
  );
}
