"use client";

import { ChevronLeft, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";

interface SlideNavigationProps {
  currentSlide: number;
  totalSlides: number;
  onPrevious: () => void;
  onNext: () => void;
  variant?: "primary" | "light";
}

export function SlideNavigation({
  currentSlide,
  totalSlides,
  onPrevious,
  onNext,
  variant = "light",
}: SlideNavigationProps) {
  const isFirst = currentSlide === 1;
  const isLast = currentSlide === totalSlides;

  const buttonStyles = {
    primary: "text-white/80 hover:text-white hover:bg-white/10 disabled:text-white/30",
    light: "text-foreground/70 hover:text-foreground hover:bg-foreground/5 disabled:text-foreground/20",
  };

  const textStyles = {
    primary: "text-white/60",
    light: "text-muted-foreground",
  };

  return (
    <div className="absolute bottom-4 left-0 right-0 flex items-center justify-between px-6 md:px-8">
      {/* Previous Button */}
      <button
        onClick={onPrevious}
        disabled={isFirst}
        className={cn(
          "p-2 rounded-lg transition-all duration-200 cursor-pointer disabled:cursor-not-allowed",
          buttonStyles[variant]
        )}
        aria-label="Previous slide"
      >
        <ChevronLeft className="w-6 h-6" />
      </button>

      {/* Slide Counter */}
      <div className={cn("text-sm font-medium tracking-wide", textStyles[variant])}>
        {currentSlide} / {totalSlides}
      </div>

      {/* Next Button */}
      <button
        onClick={onNext}
        disabled={isLast}
        className={cn(
          "p-2 rounded-lg transition-all duration-200 cursor-pointer disabled:cursor-not-allowed",
          buttonStyles[variant]
        )}
        aria-label="Next slide"
      >
        <ChevronRight className="w-6 h-6" />
      </button>
    </div>
  );
}
