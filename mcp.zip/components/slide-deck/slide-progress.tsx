"use client";

import { cn } from "@/lib/utils";

interface SlideProgressProps {
  currentSlide: number;
  totalSlides: number;
  variant?: "primary" | "light";
}

export function SlideProgress({
  currentSlide,
  totalSlides,
  variant = "light",
}: SlideProgressProps) {
  const progress = (currentSlide / totalSlides) * 100;

  const trackStyles = {
    primary: "bg-white/20",
    light: "bg-foreground/10",
  };

  const barStyles = {
    primary: "bg-white/60",
    light: "bg-primary",
  };

  return (
    <div className="absolute top-0 left-0 right-0 h-1">
      <div className={cn("w-full h-full", trackStyles[variant])}>
        <div
          className={cn(
            "h-full transition-all duration-300 ease-out",
            barStyles[variant]
          )}
          style={{ width: `${progress}%` }}
        />
      </div>
    </div>
  );
}
