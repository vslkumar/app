"use client";

import { cn } from "@/lib/utils";

interface SlideContainerProps {
  children: React.ReactNode;
  variant?: "primary" | "light";
  className?: string;
}

export function SlideContainer({
  children,
  variant = "light",
  className,
}: SlideContainerProps) {
  const variantStyles = {
    primary: "bg-slide-bg-primary text-slide-text-on-primary",
    light: "bg-slide-bg-light text-slide-text-on-light",
  };

  return (
    <div
      className={cn(
        "relative w-full h-full overflow-hidden",
        variantStyles[variant],
        className
      )}
    >
      <div className="absolute inset-0 flex flex-col" style={{ padding: "clamp(1rem, 3.5vw, 2.5rem) clamp(1.25rem, 4vw, 3rem)" }}>
        {children}
      </div>
    </div>
  );
}
