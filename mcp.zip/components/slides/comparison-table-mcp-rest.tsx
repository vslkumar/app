"use client";

import { useState } from "react";
import {
  Users,
  Database,
  RefreshCw,
  Search,
  MessageSquare,
  GitBranch,
} from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";

interface ComparisonRow {
  dimension: string;
  icon: React.ReactNode;
  rest: string;
  mcp: string;
  tooltip: string;
}

const comparisonData: ComparisonRow[] = [
  {
    dimension: "Primary Consumer",
    icon: <Users className="w-4 h-4" />,
    rest: "Developer-written code",
    mcp: "AI agents and LLMs",
    tooltip: "REST APIs are designed for developers to integrate manually; MCP is designed for AI to discover and use autonomously.",
  },
  {
    dimension: "Data Handling",
    icon: <Database className="w-4 h-4" />,
    rest: "Discrete data exchange",
    mcp: "Rich context awareness",
    tooltip: "REST returns raw data; MCP provides contextual understanding that AI can reason about.",
  },
  {
    dimension: "State",
    icon: <RefreshCw className="w-4 h-4" />,
    rest: "Stateless (manual context)",
    mcp: "Stateful sessions (built-in)",
    tooltip: "REST requires passing context with each request; MCP maintains conversation state automatically.",
  },
  {
    dimension: "Discovery",
    icon: <Search className="w-4 h-4" />,
    rest: "Static docs, manual setup",
    mcp: "Runtime dynamic discovery",
    tooltip: "REST needs upfront documentation; MCP allows AI to discover tools at runtime via introspection.",
  },
  {
    dimension: "Feedback",
    icon: <MessageSquare className="w-4 h-4" />,
    rest: "HTTP codes (404, 500)",
    mcp: "Semantic, actionable responses",
    tooltip: "REST returns status codes; MCP provides context-aware feedback AI can understand and act upon.",
  },
  {
    dimension: "Scaling",
    icon: <GitBranch className="w-4 h-4" />,
    rest: "N×M (exponential)",
    mcp: "N+M (linear, hub-spoke)",
    tooltip: "Adding 10 tools to 5 models: REST needs 50 integrations; MCP needs only 15.",
  },
];

export function ComparisonTableMCPvsREST() {
  const [hoveredRow, setHoveredRow] = useState<number | null>(null);

  return (
    <TooltipProvider delayDuration={200}>
      <div className="w-full overflow-hidden rounded-lg border border-border shadow-lg">
        <table className="w-full text-sm">
          {/* Header */}
          <thead>
            <tr className="bg-primary text-primary-foreground">
              <th className="px-4 py-3 text-left font-semibold">
                <span className="flex items-center gap-2">
                  Dimension
                </span>
              </th>
              <th className="px-4 py-3 text-left font-semibold">
                <span className="flex items-center gap-2">
                  <span className="inline-flex items-center justify-center w-6 h-6 rounded bg-white/20 text-xs font-bold">
                    R
                  </span>
                  REST API
                </span>
              </th>
              <th className="px-4 py-3 text-left font-semibold">
                <span className="flex items-center gap-2">
                  <span className="inline-flex items-center justify-center w-6 h-6 rounded bg-white/20 text-xs font-bold">
                    M
                  </span>
                  MCP
                </span>
              </th>
            </tr>
          </thead>

          {/* Body */}
          <tbody>
            {comparisonData.map((row, index) => (
              <Tooltip key={row.dimension}>
                <TooltipTrigger asChild>
                  <tr
                    className={`
                      transition-colors duration-150 cursor-pointer
                      ${index % 2 === 0 ? "bg-card" : "bg-muted/30"}
                      ${hoveredRow === index ? "bg-accent/10" : ""}
                    `}
                    onMouseEnter={() => setHoveredRow(index)}
                    onMouseLeave={() => setHoveredRow(null)}
                  >
                    <td className="px-4 py-3 border-t border-border">
                      <span className="flex items-center gap-2 font-medium text-foreground">
                        <span className="inline-flex items-center justify-center w-7 h-7 rounded-md bg-primary/10 text-primary">
                          {row.icon}
                        </span>
                        {row.dimension}
                      </span>
                    </td>
                    <td className="px-4 py-3 border-t border-border text-muted-foreground">
                      {row.rest}
                    </td>
                    <td className="px-4 py-3 border-t border-border">
                      <span className="text-primary font-medium">
                        {row.mcp}
                      </span>
                    </td>
                  </tr>
                </TooltipTrigger>
                <TooltipContent
                  side="top"
                  className="max-w-xs text-sm bg-foreground text-background p-3"
                >
                  {row.tooltip}
                </TooltipContent>
              </Tooltip>
            ))}
          </tbody>
        </table>
      </div>
    </TooltipProvider>
  );
}
