"use client";

import { InteractiveWorkflowDiagram } from "./interactive-workflow-diagram";

export function Slide4Workflow() {
  return (
    <div className="flex flex-col h-full">
      {/* Slide Number */}
      <div className="text-6xl font-bold text-foreground/5 absolute top-4 left-6">
        04
      </div>

      {/* Title */}
      <h2 className="text-2xl md:text-3xl font-bold text-primary mb-1">
        The Communication Workflow
      </h2>

      <p className="text-base text-muted-foreground mb-4">
        Five-Step Intelligence Cycle
      </p>

      {/* Interactive Workflow Diagram */}
      <div className="flex-1 flex items-center justify-center px-2">
        <InteractiveWorkflowDiagram />
      </div>
    </div>
  );
}
