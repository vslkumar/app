"use client";

import { useState } from "react";
import { cn } from "@/lib/utils";

interface AdvantageCardProps {
  icon: React.ReactNode;
  title: string;
  bullets: string[];
  delay?: number;
}

function AdvantageCard({ icon, title, bullets, delay = 0 }: AdvantageCardProps) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div
      className={cn(
        "group relative flex flex-col items-center p-4 md:p-6 rounded-xl bg-card border border-border/50",
        "transition-all duration-300 ease-out cursor-pointer",
        isHovered && "shadow-lg shadow-primary/10 -translate-y-1 border-primary/30"
      )}
      style={{
        animationDelay: `${delay}ms`,
      }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Icon Container */}
      <div
        className={cn(
          "w-14 h-14 md:w-16 md:h-16 rounded-full bg-primary flex items-center justify-center mb-3 md:mb-4",
          "transition-all duration-300 ease-out",
          isHovered && "scale-110 shadow-md shadow-primary/30"
        )}
      >
        <div className="text-primary-foreground w-7 h-7 md:w-8 md:h-8">
          {icon}
        </div>
      </div>

      {/* Title */}
      <h3
        className={cn(
          "text-base md:text-lg font-semibold text-foreground mb-2 md:mb-3 text-center",
          "transition-colors duration-300",
          isHovered && "text-primary"
        )}
      >
        {title}
      </h3>

      {/* Bullet Points */}
      <ul className="space-y-1 md:space-y-1.5 text-left w-full">
        {bullets.map((bullet, index) => (
          <li
            key={index}
            className="flex items-start text-xs md:text-sm text-muted-foreground leading-relaxed"
          >
            <span
              className={cn(
                "w-1.5 h-1.5 rounded-full bg-primary/60 mt-1.5 mr-2 flex-shrink-0",
                "transition-all duration-300",
                isHovered && "bg-primary scale-110"
              )}
            />
            <span className={cn(
              "transition-colors duration-300",
              isHovered && "text-foreground/80"
            )}>
              {bullet}
            </span>
          </li>
        ))}
      </ul>

      {/* Subtle gradient overlay on hover */}
      <div
        className={cn(
          "absolute inset-0 rounded-xl pointer-events-none",
          "bg-gradient-to-b from-primary/0 to-primary/0",
          "transition-all duration-300",
          isHovered && "from-primary/[0.02] to-primary/[0.06]"
        )}
      />
    </div>
  );
}

// Custom SVG Icons matching corporate modern style
function ScalabilityIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      className="w-full h-full"
    >
      {/* Network/hub pattern showing N+M scaling */}
      <circle cx="12" cy="12" r="3" />
      <circle cx="12" cy="4" r="1.5" />
      <circle cx="12" cy="20" r="1.5" />
      <circle cx="4" cy="12" r="1.5" />
      <circle cx="20" cy="12" r="1.5" />
      <circle cx="6" cy="6" r="1.5" />
      <circle cx="18" cy="6" r="1.5" />
      <circle cx="6" cy="18" r="1.5" />
      <circle cx="18" cy="18" r="1.5" />
      <line x1="12" y1="9" x2="12" y2="5.5" />
      <line x1="12" y1="15" x2="12" y2="18.5" />
      <line x1="9" y1="12" x2="5.5" y2="12" />
      <line x1="15" y1="12" x2="18.5" y2="12" />
      <line x1="9.9" y1="9.9" x2="7.2" y2="7.2" />
      <line x1="14.1" y1="9.9" x2="16.8" y2="7.2" />
      <line x1="9.9" y1="14.1" x2="7.2" y2="16.8" />
      <line x1="14.1" y1="14.1" x2="16.8" y2="16.8" />
    </svg>
  );
}

function InteroperabilityIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      className="w-full h-full"
    >
      {/* Plug/connection symbol */}
      <rect x="2" y="8" width="8" height="8" rx="1" />
      <rect x="14" y="8" width="8" height="8" rx="1" />
      <line x1="10" y1="11" x2="14" y2="11" />
      <line x1="10" y1="13" x2="14" y2="13" />
      {/* Dots inside boxes representing different systems */}
      <circle cx="5" cy="11" r="0.5" fill="currentColor" />
      <circle cx="7" cy="11" r="0.5" fill="currentColor" />
      <circle cx="5" cy="13" r="0.5" fill="currentColor" />
      <circle cx="7" cy="13" r="0.5" fill="currentColor" />
      <circle cx="17" cy="11" r="0.5" fill="currentColor" />
      <circle cx="19" cy="11" r="0.5" fill="currentColor" />
      <circle cx="17" cy="13" r="0.5" fill="currentColor" />
      <circle cx="19" cy="13" r="0.5" fill="currentColor" />
      {/* Arrows indicating bidirectional */}
      <polyline points="11 9 12 8 13 9" />
      <polyline points="11 15 12 16 13 15" />
    </svg>
  );
}

function UpdatesIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      className="w-full h-full"
    >
      {/* Gear with refresh arrow */}
      <circle cx="12" cy="12" r="3" />
      <path d="M12 1v3" />
      <path d="M12 20v3" />
      <path d="M4.22 4.22l2.12 2.12" />
      <path d="M17.66 17.66l2.12 2.12" />
      <path d="M1 12h3" />
      <path d="M20 12h3" />
      <path d="M4.22 19.78l2.12-2.12" />
      <path d="M17.66 6.34l2.12-2.12" />
      {/* Small refresh arrow */}
      <path d="M16 12a4 4 0 0 1-4 4" strokeWidth="1.2" />
      <polyline points="14.5 15 12 16 12.5 13.5" strokeWidth="1.2" />
    </svg>
  );
}

export function AdvantagesIconGrid() {
  const advantages: AdvantageCardProps[] = [
    {
      icon: <ScalabilityIcon />,
      title: "Scalability",
      bullets: [
        "From N×M to N+M complexity",
        "One server per tool, any client",
        "Linear vs exponential growth",
      ],
      delay: 0,
    },
    {
      icon: <InteroperabilityIcon />,
      title: "Interoperability",
      bullets: [
        "Write once, run anywhere",
        "No vendor lock-in",
        "Universal protocol standard",
      ],
      delay: 100,
    },
    {
      icon: <UpdatesIcon />,
      title: "Provider-Managed Updates",
      bullets: [
        "Providers maintain servers",
        "API changes handled remotely",
        "Reduced maintenance burden",
      ],
      delay: 200,
    },
  ];

  return (
    <div className="w-full h-full flex items-center justify-center">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6 w-full max-w-5xl">
        {advantages.map((advantage, index) => (
          <AdvantageCard
            key={index}
            icon={advantage.icon}
            title={advantage.title}
            bullets={advantage.bullets}
            delay={advantage.delay}
          />
        ))}
      </div>
    </div>
  );
}
