"use client";

import { MCPArchitectureDiagram } from "@/components/diagrams/mcp-architecture-diagram";

export function Slide3Architecture() {
  return (
    <div className="flex flex-col h-full">
      {/* Slide Number */}
      <div className="text-6xl font-bold text-foreground/5 absolute top-4 left-6">
        03
      </div>

      {/* Title */}
      <h2 className="text-2xl md:text-3xl font-bold text-primary mb-2">
        MCP Architecture: The Three-Tier Model
      </h2>

      {/* Architecture Diagram */}
      <div className="flex-1 flex items-center justify-center min-h-0">
        <MCPArchitectureDiagram />
      </div>

      {/* Key insight */}
      <div className="text-center text-sm text-muted-foreground pb-2">
        Host coordinates multiple Clients, each maintaining a dedicated stateful connection to one Server
      </div>
    </div>
  );
}
