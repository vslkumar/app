"use client";

import { BrainInABoxVisual } from "@/components/visuals/brain-in-a-box-visual";

export function Slide2ProblemStatement() {
  return (
    <div className="flex flex-col h-full">
      {/* Slide Number watermark */}
      <div className="text-6xl font-bold text-foreground/5 absolute top-4 left-6 pointer-events-none select-none">
        02
      </div>

      {/* Title */}
      <h2 className="text-2xl md:text-3xl font-bold text-primary mb-3">
        The Problem: AI in Isolation
      </h2>

      {/* Content Grid */}
      <div className="flex-1 flex gap-6 min-h-0">
        {/* Left: Bullet Points */}
        <div className="flex-1 flex items-center">
          <ul className="space-y-3 text-sm md:text-base text-foreground/80 w-full">
            <li className="flex items-start gap-3">
              <span className="w-2 h-2 mt-1.5 bg-primary rounded-full flex-shrink-0" />
              <span>
                <strong className="text-foreground">Static Knowledge:</strong>{" "}
                LLMs are trained on fixed datasets, frozen in time
              </span>
            </li>
            <li className="flex items-start gap-3">
              <span className="w-2 h-2 mt-1.5 bg-primary rounded-full flex-shrink-0" />
              <span>
                <strong className="text-foreground">No Real-Time Access:</strong>{" "}
                Cannot query current information or private databases
              </span>
            </li>
            <li className="flex items-start gap-3">
              <span className="w-2 h-2 mt-1.5 bg-primary rounded-full flex-shrink-0" />
              <span>
                <strong className="text-foreground">Limited Actions:</strong>{" "}
                Unable to execute tasks in external systems
              </span>
            </li>
            <li className="flex items-start gap-3">
              <span className="w-2 h-2 mt-1.5 bg-primary rounded-full flex-shrink-0" />
              <span>
                <strong className="text-foreground">Integration Chaos:</strong>{" "}
                Every new connection requires custom code
              </span>
            </li>
          </ul>
        </div>

        {/* Right: Brain in Box Visual */}
        <div className="flex-1 flex items-center justify-center min-h-0">
          <BrainInABoxVisual />
        </div>
      </div>
    </div>
  );
}
