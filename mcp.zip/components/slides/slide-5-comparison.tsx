"use client";

import { ComparisonTableMCPvsREST } from "./comparison-table-mcp-rest";

export function Slide5Comparison() {
  return (
    <div className="flex flex-col h-full">
      {/* Slide Number */}
      <div className="text-6xl font-bold text-foreground/5 absolute top-4 left-6">
        05
      </div>

      {/* Header */}
      <div className="mb-4">
        <h2 className="text-2xl md:text-3xl font-bold text-primary mb-1">
          MCP vs REST APIs
        </h2>
        <p className="text-sm text-muted-foreground">
          Different tools for different jobs — hover rows for details
        </p>
      </div>

      {/* Comparison Table */}
      <div className="flex-1 flex items-center justify-center">
        <div className="w-full max-w-4xl">
          <ComparisonTableMCPvsREST />
        </div>
      </div>
    </div>
  );
}
