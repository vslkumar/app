"use client";

import { AnimatedUSBCIcon } from "./animated-usbc-icon";

export function Slide1TitleSlide() {
  return (
    <div className="flex items-center justify-between h-full gap-6 px-2">
      {/* Left: Animated USB-C Visual */}
      <div
        style={{
          flex: "0 0 42%",
          height: "78%",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <AnimatedUSBCIcon />
      </div>

      {/* Right: Title text */}
      <div
        style={{
          flex: "1 1 0%",
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          gap: "1rem",
        }}
      >
        {/* Eyebrow */}
        <p
          style={{
            fontSize: "clamp(0.65rem, 1.2vw, 0.85rem)",
            fontWeight: 600,
            letterSpacing: "0.18em",
            textTransform: "uppercase",
            color: "rgba(255,255,255,0.55)",
            marginBottom: "0.25rem",
          }}
        >
          A Technical Deep Dive
        </p>

        {/* Main title */}
        <h1
          style={{
            fontSize: "clamp(1.4rem, 3.5vw, 2.8rem)",
            fontWeight: 800,
            lineHeight: 1.12,
            color: "#ffffff",
            margin: 0,
          }}
        >
          Understanding
          <br />
          <span style={{ color: "rgba(255,255,255,0.90)" }}>
            Model Context
          </span>
          <br />
          <span
            style={{
              color: "rgba(255,255,255,0.70)",
              fontWeight: 700,
            }}
          >
            Protocol (MCP)
          </span>
        </h1>

        {/* Divider */}
        <div
          style={{
            width: "48px",
            height: "3px",
            borderRadius: "2px",
            background: "rgba(255,255,255,0.45)",
            margin: "0.25rem 0",
          }}
        />

        {/* Subtitle / analogy */}
        <p
          style={{
            fontSize: "clamp(0.85rem, 1.8vw, 1.2rem)",
            fontWeight: 400,
            color: "rgba(255,255,255,0.80)",
            lineHeight: 1.45,
            margin: 0,
          }}
        >
          &ldquo;The{" "}
          <span
            style={{
              fontWeight: 700,
              color: "#ffffff",
              borderBottom: "1.5px solid rgba(255,255,255,0.45)",
              paddingBottom: "1px",
            }}
          >
            USB-C
          </span>{" "}
          for AI Integrations&rdquo;
        </p>

        {/* Sub-text */}
        <p
          style={{
            fontSize: "clamp(0.7rem, 1.1vw, 0.8rem)",
            color: "rgba(255,255,255,0.45)",
            margin: 0,
            lineHeight: 1.5,
          }}
        >
          For developers, AI engineers &amp; architects
        </p>
      </div>
    </div>
  );
}
