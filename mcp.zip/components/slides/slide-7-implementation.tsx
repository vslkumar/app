"use client";

import { SyntaxHighlightedCodeBlock } from "@/components/syntax-highlighted-code-block";
import { Code2, Server, Plug } from "lucide-react";

export function Slide7Implementation() {
  const keyPoints = [
    { icon: Code2, text: "Tools are just Python functions" },
    { icon: Server, text: "FastMCP handles protocol complexity" },
    { icon: Plug, text: "Production-ready in minutes" },
  ];

  return (
    <div className="flex flex-col h-full">
      {/* Slide Number watermark */}
      <div className="text-6xl font-bold text-foreground/5 absolute top-4 left-6 pointer-events-none select-none">
        07
      </div>

      {/* Title */}
      <h2 className="text-2xl md:text-3xl font-bold text-primary mb-1">
        Practical Implementation
      </h2>

      {/* Subtitle */}
      <p className="text-sm text-muted-foreground mb-3">
        Building Your First MCP Server in Python
      </p>

      {/* Main Content */}
      <div className="flex-1 flex flex-row gap-4 min-h-0 overflow-hidden">
        {/* Code Block */}
        <div className="flex-1 min-w-0 min-h-0 overflow-hidden">
          <SyntaxHighlightedCodeBlock />
        </div>

        {/* Key Points Sidebar */}
        <div className="w-[30%] flex-shrink-0 flex flex-col gap-2.5">
          <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-0.5">
            Key Takeaways
          </div>
          {keyPoints.map((point, index) => {
            const Icon = point.icon;
            return (
              <div
                key={index}
                className="flex items-center gap-2.5 p-2.5 rounded-lg bg-secondary/50 border border-border/50 transition-colors hover:bg-secondary/80"
              >
                <div className="flex-shrink-0 w-7 h-7 rounded-md bg-primary/10 flex items-center justify-center">
                  <Icon className="w-3.5 h-3.5 text-primary" />
                </div>
                <span className="text-sm font-medium text-foreground/90 leading-tight">
                  {point.text}
                </span>
              </div>
            );
          })}

          {/* Decorator highlight note */}
          <div className="mt-1 p-2.5 rounded-lg bg-primary/5 border border-primary/20">
            <div className="text-xs font-medium text-primary mb-1">Pro Tip</div>
            <p className="text-xs text-muted-foreground leading-relaxed">
              The{" "}
              <code className="px-1 py-0.5 rounded bg-primary/10 text-primary font-mono text-[10px]">
                @mcp.tool()
              </code>{" "}
              decorator auto-generates schemas from type hints.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
