"use client";

import { useState, useCallback } from "react";
import { Search, Map, Brain, Play, MessageSquare } from "lucide-react";

interface WorkflowStep {
  id: number;
  label: string;
  description: string;
  codeSnippet: string;
  icon: React.ReactNode;
}

const workflowSteps: WorkflowStep[] = [
  {
    id: 1,
    label: "Introspection",
    description: "Client discovers available capabilities via standardized queries",
    codeSnippet: "tools/list\nresources/list\nprompts/list",
    icon: <Search className="w-5 h-5" />,
  },
  {
    id: 2,
    label: "Mapping",
    description: "LLM analyzes user intent against discovered tools using semantic matching",
    codeSnippet: '"get weather" → weather_current',
    icon: <Map className="w-5 h-5" />,
  },
  {
    id: 3,
    label: "Decision",
    description: "AI selects appropriate tool and constructs validated arguments",
    codeSnippet: "{ tool: 'weather',\n  args: { city: 'NYC' } }",
    icon: <Brain className="w-5 h-5" />,
  },
  {
    id: 4,
    label: "Execution",
    description: "Client invokes the tool on server, handles errors, returns rich content",
    codeSnippet: "tools/call → execute\n→ return result",
    icon: <Play className="w-5 h-5" />,
  },
  {
    id: 5,
    label: "Response",
    description: "LLM integrates results into context, generates natural language response",
    codeSnippet: "context.add(result)\n→ generate_reply()",
    icon: <MessageSquare className="w-5 h-5" />,
  },
];

export function InteractiveWorkflowDiagram() {
  const [activeStep, setActiveStep] = useState<number | null>(null);
  const [hoveredStep, setHoveredStep] = useState<number | null>(null);

  const handleStepClick = useCallback((stepId: number) => {
    setActiveStep(activeStep === stepId ? null : stepId);
  }, [activeStep]);

  const handleStepHover = useCallback((stepId: number | null) => {
    setHoveredStep(stepId);
  }, []);

  // Calculate positions for 5 nodes in a circle
  const getNodePosition = (index: number, total: number) => {
    // Start from top (-90 degrees) and go clockwise
    const angleOffset = -90;
    const angle = (angleOffset + (index / total) * 360) * (Math.PI / 180);
    const radius = 120;
    const centerX = 180;
    const centerY = 140;
    
    return {
      x: centerX + radius * Math.cos(angle),
      y: centerY + radius * Math.sin(angle),
    };
  };

  // Generate curved arrow path between two points
  const getArrowPath = (startIndex: number, endIndex: number, total: number) => {
    const start = getNodePosition(startIndex, total);
    const end = getNodePosition(endIndex, total);
    
    const centerX = 180;
    const centerY = 140;
    
    // Calculate control point for curve (pull towards center)
    const midX = (start.x + end.x) / 2;
    const midY = (start.y + end.y) / 2;
    const pullFactor = 0.3;
    const controlX = midX + (centerX - midX) * pullFactor;
    const controlY = midY + (centerY - midY) * pullFactor;
    
    // Adjust start and end points to account for node radius
    const nodeRadius = 28;
    const startAngle = Math.atan2(end.y - start.y, end.x - start.x);
    const endAngle = Math.atan2(start.y - end.y, start.x - end.x);
    
    const adjustedStartX = start.x + nodeRadius * Math.cos(startAngle);
    const adjustedStartY = start.y + nodeRadius * Math.sin(startAngle);
    const adjustedEndX = end.x + nodeRadius * Math.cos(endAngle);
    const adjustedEndY = end.y + nodeRadius * Math.sin(endAngle);
    
    return `M ${adjustedStartX} ${adjustedStartY} Q ${controlX} ${controlY} ${adjustedEndX} ${adjustedEndY}`;
  };

  const displayStep = activeStep !== null ? activeStep : hoveredStep;
  const currentStepData = displayStep !== null ? workflowSteps.find(s => s.id === displayStep) : null;

  return (
    <div className="flex flex-col lg:flex-row items-center justify-center gap-6 w-full h-full">
      {/* SVG Diagram */}
      <div className="relative flex-shrink-0">
        <svg
          width="360"
          height="280"
          viewBox="0 0 360 280"
          className="overflow-visible"
        >
          <defs>
            {/* Arrow marker */}
            <marker
              id="arrowhead"
              markerWidth="8"
              markerHeight="6"
              refX="6"
              refY="3"
              orient="auto"
              markerUnits="strokeWidth"
            >
              <polygon
                points="0 0, 8 3, 0 6"
                fill="rgba(59,91,219,0.4)"
              />
            </marker>
            <marker
              id="arrowhead-active"
              markerWidth="8"
              markerHeight="6"
              refX="6"
              refY="3"
              orient="auto"
              markerUnits="strokeWidth"
            >
              <polygon
                points="0 0, 8 3, 0 6"
                fill="#3b5bdb"
              />
            </marker>
            
            {/* Glow filter for active nodes */}
            <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
              <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
              <feMerge>
                <feMergeNode in="coloredBlur"/>
                <feMergeNode in="SourceGraphic"/>
              </feMerge>
            </filter>
          </defs>

          {/* Connection arrows */}
          {workflowSteps.map((_, index) => {
            const nextIndex = (index + 1) % workflowSteps.length;
            const isActiveConnection = 
              (activeStep !== null && (activeStep === index + 1 || activeStep === nextIndex + 1)) ||
              (hoveredStep !== null && (hoveredStep === index + 1 || hoveredStep === nextIndex + 1));
            
            return (
              <path
                key={`arrow-${index}`}
                d={getArrowPath(index, nextIndex, workflowSteps.length)}
                fill="none"
                stroke={isActiveConnection ? "#3b5bdb" : "rgba(100,116,139,0.3)"}
                strokeWidth={isActiveConnection ? "2.5" : "1.5"}
                style={{ transition: "stroke 0.3s, stroke-width 0.3s" }}
                markerEnd={isActiveConnection ? "url(#arrowhead-active)" : "url(#arrowhead)"}
                strokeDasharray={isActiveConnection ? undefined : "4 3"}
              />
            );
          })}

          {/* Center icon - user query representation */}
          <g>
            <circle
              cx="180"
              cy="140"
              r="20"
              fill="rgba(241,245,249,0.5)"
              stroke="rgba(100,116,139,0.2)"
              strokeWidth="1"
            />
            <text
              x="180"
              y="145"
              textAnchor="middle"
              fontSize="10"
              fontWeight="500"
              fill="#64748b"
            >
              Query
            </text>
          </g>

          {/* Workflow nodes */}
          {workflowSteps.map((step, index) => {
            const pos = getNodePosition(index, workflowSteps.length);
            const isActive = activeStep === step.id;
            const isHovered = hoveredStep === step.id;
            const isHighlighted = isActive || isHovered;
            const scale = isHighlighted ? 1.08 : 1;
            
            return (
              <g
                key={step.id}
                className="cursor-pointer"
                transform={`translate(${pos.x}, ${pos.y}) scale(${scale})`}
                style={{ transformOrigin: `${pos.x}px ${pos.y}px`, transformBox: "fill-box", transition: "transform 0.2s ease" }}
                onClick={() => handleStepClick(step.id)}
                onMouseEnter={() => handleStepHover(step.id)}
                onMouseLeave={() => handleStepHover(null)}
              >
                {/* Node circle - positioned at origin since we're using transform */}
                <circle
                  cx="0"
                  cy="0"
                  r="28"
                  fill={isHighlighted ? "#3b5bdb" : "#ffffff"}
                  stroke={isHighlighted ? "#3b5bdb" : "#e2e8f0"}
                  strokeWidth={isHighlighted ? "2" : "1.5"}
                  style={{ transition: "fill 0.3s, stroke 0.3s" }}
                  filter={isHighlighted ? "url(#glow)" : undefined}
                />
                
                {/* Step number badge */}
                <circle
                  cx="18"
                  cy="-18"
                  r="10"
                  fill={isHighlighted ? "#ffffff" : "#f1f5f9"}
                  stroke={isHighlighted ? "#3b5bdb" : "#e2e8f0"}
                  strokeWidth="1"
                  style={{ transition: "fill 0.3s, stroke 0.3s" }}
                />
                <text
                  x="18"
                  y="-14"
                  textAnchor="middle"
                  fontSize="10"
                  fontWeight="bold"
                  fill={isHighlighted ? "#3b5bdb" : "#64748b"}
                  style={{ transition: "fill 0.3s" }}
                >
                  {step.id}
                </text>
                
                {/* Icon rendered as foreignObject */}
                <foreignObject x="-10" y="-10" width="20" height="20" style={{ overflow: "visible" }}>
                  <div
                    style={{
                      width: 20,
                      height: 20,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      color: isHighlighted ? "#ffffff" : "#3b5bdb",
                      transition: "color 0.3s",
                    }}
                  >
                    {step.icon}
                  </div>
                </foreignObject>
              </g>
            );
          })}

          {/* Node labels (positioned outside the circle) */}
          {workflowSteps.map((step, index) => {
            const pos = getNodePosition(index, workflowSteps.length);
            const centerX = 180;
            const centerY = 140;
            
            // Position label further from center than the node
            const labelRadius = 165;
            const angle = (-90 + (index / workflowSteps.length) * 360) * (Math.PI / 180);
            const labelX = centerX + labelRadius * Math.cos(angle);
            const labelY = centerY + labelRadius * Math.sin(angle);
            
            const isHighlighted = activeStep === step.id || hoveredStep === step.id;
            
            return (
              <text
                key={`label-${step.id}`}
                x={labelX}
                y={labelY + 4}
                textAnchor="middle"
                fontSize="11"
                fontWeight="600"
                fill={isHighlighted ? "#3b5bdb" : "rgba(30,41,59,0.7)"}
                style={{ transition: "fill 0.3s", pointerEvents: "none" }}
              >
                {step.label}
              </text>
            );
          })}
        </svg>
      </div>

      {/* Info Panel */}
      <div className="flex-1 max-w-xs lg:max-w-sm min-h-[140px] flex flex-col">
        {currentStepData ? (
          <div className="bg-card border border-border rounded-lg p-4 shadow-sm transition-all duration-300 animate-in fade-in-0 slide-in-from-right-2">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-primary-foreground">
                {currentStepData.icon}
              </div>
              <div>
                <span className="text-xs text-muted-foreground font-medium">Step {currentStepData.id}</span>
                <h4 className="text-base font-bold text-foreground leading-tight">
                  {currentStepData.label}
                </h4>
              </div>
            </div>
            
            <p className="text-sm text-muted-foreground mb-3 leading-relaxed">
              {currentStepData.description}
            </p>
            
            <div className="bg-muted/50 rounded-md p-2 border border-border/50">
              <pre className="text-xs font-mono text-primary whitespace-pre-wrap leading-relaxed">
                {currentStepData.codeSnippet}
              </pre>
            </div>
          </div>
        ) : (
          <div className="bg-muted/30 border border-dashed border-muted-foreground/30 rounded-lg p-4 flex items-center justify-center h-full">
            <p className="text-sm text-muted-foreground text-center">
              Click or hover on a step<br />to see details
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
