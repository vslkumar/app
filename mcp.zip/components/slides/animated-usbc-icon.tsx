"use client";

import { useEffect, useState } from "react";

export function AnimatedUSBCIcon() {
  const [mounted, setMounted] = useState(false);
  const [linesVisible, setLinesVisible] = useState(false);
  const [iconsVisible, setIconsVisible] = useState(false);

  useEffect(() => {
    setMounted(true);
    const t1 = setTimeout(() => setLinesVisible(true), 400);
    const t2 = setTimeout(() => setIconsVisible(true), 900);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
    };
  }, []);

  // Central hub position
  const cx = 200;
  const cy = 200;

  // Device positions around the hub (radius ~130)
  const devices = [
    { id: "database", angle: -90, label: "Database", r: 130 },
    { id: "cloud",    angle: -18, label: "Cloud",    r: 130 },
    { id: "tools",    angle:  54, label: "Tools",    r: 130 },
    { id: "api",      angle: 126, label: "API",      r: 130 },
    { id: "model",    angle: 198, label: "Model",    r: 130 },
  ];

  function devicePos(angle: number, r: number) {
    const rad = (angle * Math.PI) / 180;
    return { x: cx + r * Math.cos(rad), y: cy + r * Math.sin(rad) };
  }

  return (
    <div
      style={{
        opacity: mounted ? 1 : 0,
        transition: "opacity 0.7s ease-in-out",
        width: "100%",
        height: "100%",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
      }}
    >
      <svg
        viewBox="0 0 400 400"
        width="100%"
        height="100%"
        xmlns="http://www.w3.org/2000/svg"
        aria-label="Animated USB-C hub connecting multiple devices"
        role="img"
        style={{ overflow: "visible", maxWidth: 340, maxHeight: 340 }}
      >
        <defs>
          {/* Pulse animation for connection lines */}
          <style>{`
            @keyframes pulse-dash {
              0%   { stroke-dashoffset: 0; }
              100% { stroke-dashoffset: -40; }
            }
            @keyframes glow-pulse {
              0%, 100% { opacity: 0.25; r: 44; }
              50%       { opacity: 0.45; r: 50; }
            }
            @keyframes icon-pop {
              0%   { transform: scale(0.4); opacity: 0; }
              60%  { transform: scale(1.12); opacity: 1; }
              100% { transform: scale(1);   opacity: 1; }
            }
            @keyframes line-grow {
              0%   { stroke-dashoffset: 140; }
              100% { stroke-dashoffset: 0; }
            }
            @keyframes hub-spin {
              from { transform: rotate(0deg);   }
              to   { transform: rotate(360deg); }
            }
            @keyframes center-fade {
              0%   { opacity: 0; transform: scale(0.7); }
              100% { opacity: 1; transform: scale(1); }
            }
          `}</style>

          {/* Radial glow for hub */}
          <radialGradient id="hubGlow" cx="50%" cy="50%" r="50%">
            <stop offset="0%"   stopColor="#ffffff" stopOpacity="0.18" />
            <stop offset="100%" stopColor="#ffffff" stopOpacity="0"    />
          </radialGradient>

          {/* Clip so dashes stay within the line length */}
          <marker id="arrowHead" markerWidth="6" markerHeight="6"
            refX="3" refY="3" orient="auto">
            <circle cx="3" cy="3" r="1.5" fill="rgba(255,255,255,0.7)" />
          </marker>
        </defs>

        {/* === Background glow halo === */}
        <circle
          cx={cx} cy={cy} r="46"
          fill="url(#hubGlow)"
          style={{ animation: "glow-pulse 2.8s ease-in-out infinite" }}
        />

        {/* === Connection lines (drawn from hub outward) === */}
        {devices.map((dev, i) => {
          const pos = devicePos(dev.angle, dev.r - 28);
          const hubEdge = devicePos(dev.angle, 38);
          const len = Math.sqrt(
            (pos.x - hubEdge.x) ** 2 + (pos.y - hubEdge.y) ** 2
          );
          return (
            <g key={`line-${dev.id}`}>
              {/* Base line (reveal animation) */}
              <line
                x1={hubEdge.x} y1={hubEdge.y}
                x2={pos.x}      y2={pos.y}
                stroke="rgba(255,255,255,0.30)"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeDasharray={len}
                strokeDashoffset={linesVisible ? 0 : len}
                style={{
                  transition: `stroke-dashoffset 0.55s cubic-bezier(.4,0,.2,1) ${i * 0.1}s`,
                }}
              />
              {/* Animated pulse dash on top */}
              <line
                x1={hubEdge.x} y1={hubEdge.y}
                x2={pos.x}      y2={pos.y}
                stroke="rgba(255,255,255,0.75)"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeDasharray="8 32"
                strokeDashoffset="0"
                style={{
                  opacity: linesVisible ? 1 : 0,
                  transition: `opacity 0.4s ease ${i * 0.1 + 0.55}s`,
                  animation: linesVisible
                    ? `pulse-dash 1.4s linear infinite ${i * 0.28}s`
                    : "none",
                }}
              />
            </g>
          );
        })}

        {/* === Device icon nodes === */}
        {devices.map((dev, i) => {
          const pos = devicePos(dev.angle, dev.r);
          return (
            <g
              key={`device-${dev.id}`}
              transform={`translate(${pos.x}, ${pos.y})`}
              style={{
                transformOrigin: `${pos.x}px ${pos.y}px`,
                opacity: iconsVisible ? 1 : 0,
                animation: iconsVisible
                  ? `icon-pop 0.45s cubic-bezier(.4,0,.2,1) ${i * 0.1}s both`
                  : "none",
              }}
            >
              {/* Outer ring */}
              <circle r="22" fill="none" stroke="rgba(255,255,255,0.55)" strokeWidth="1.2" />
              {/* Inner fill */}
              <circle r="19" fill="rgba(255,255,255,0.10)" />

              {/* Device icon */}
              {dev.id === "database" && (
                <g transform="translate(-8,-9)" stroke="white" strokeWidth="1.5" fill="none" strokeLinecap="round">
                  <ellipse cx="8" cy="3.5" rx="7" ry="2.5" />
                  <path d="M1 3.5v4c0 1.38 3.13 2.5 7 2.5s7-1.12 7-2.5v-4" />
                  <path d="M1 7.5v4c0 1.38 3.13 2.5 7 2.5s7-1.12 7-2.5v-4" />
                  <path d="M1 11.5v4c0 1.38 3.13 2.5 7 2.5s7-1.12 7-2.5v-4" />
                </g>
              )}
              {dev.id === "cloud" && (
                <g transform="translate(-9,-7)" stroke="white" strokeWidth="1.5" fill="none" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M17.5 9.5a4.5 4.5 0 0 0-8.84-1.5A3.5 3.5 0 1 0 4 11.5h13a3 3 0 0 0 .5-6z" />
                </g>
              )}
              {dev.id === "tools" && (
                <g transform="translate(-8,-8)" stroke="white" strokeWidth="1.5" fill="none" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.77z" />
                </g>
              )}
              {dev.id === "api" && (
                <g transform="translate(-8,-8)" stroke="white" strokeWidth="1.5" fill="none" strokeLinecap="round" strokeLinejoin="round">
                  <polyline points="16 18 22 12 16 6" />
                  <polyline points="8 6 2 12 8 18" />
                  <line x1="14" y1="4" x2="10" y2="20" />
                </g>
              )}
              {dev.id === "model" && (
                <g transform="translate(-8,-8)" stroke="white" strokeWidth="1.5" fill="none" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M12 2a2 2 0 1 0 0 4 2 2 0 0 0 0-4z" />
                  <path d="M12 18a2 2 0 1 0 0 4 2 2 0 0 0 0-4z" />
                  <path d="M4.93 4.93a2 2 0 1 0 0 4 2 2 0 0 0 0-4z" />
                  <path d="M19.07 4.93a2 2 0 1 0 0 4 2 2 0 0 0 0-4z" />
                  <line x1="12" y1="6" x2="12" y2="18" />
                  <line x1="4.93" y1="8.93" x2="12" y2="6" />
                  <line x1="19.07" y1="8.93" x2="12" y2="6" />
                </g>
              )}

              {/* Label */}
              <text
                y="32"
                textAnchor="middle"
                fontSize="9"
                fill="rgba(255,255,255,0.75)"
                fontFamily="Inter, system-ui, sans-serif"
                fontWeight="500"
                letterSpacing="0.5"
              >
                {dev.label}
              </text>
            </g>
          );
        })}

        {/* === Central USB-C Hub === */}
        <g
          transform={`translate(${cx},${cy})`}
          style={{
            animation: mounted
              ? "center-fade 0.6s cubic-bezier(.4,0,.2,1) both"
              : "none",
          }}
        >
          {/* Outer ring with subtle spin-tick decoration */}
          <circle r="36" fill="none" stroke="rgba(255,255,255,0.20)" strokeWidth="1" strokeDasharray="4 6" />
          {/* Main hub circle */}
          <circle r="30" fill="rgba(255,255,255,0.12)" stroke="rgba(255,255,255,0.85)" strokeWidth="2" />

          {/* USB-C port shape */}
          <rect
            x="-9" y="-5"
            width="18" height="10"
            rx="5" ry="5"
            fill="none"
            stroke="white"
            strokeWidth="2"
          />
          {/* Inner oval */}
          <rect
            x="-5.5" y="-2.5"
            width="11" height="5"
            rx="2.5" ry="2.5"
            fill="white"
            fillOpacity="0.85"
          />

          {/* "MCP" label below the port */}
          <text
            y="20"
            textAnchor="middle"
            fontSize="7.5"
            fill="white"
            fontFamily="Inter, system-ui, sans-serif"
            fontWeight="700"
            letterSpacing="2"
          >
            MCP
          </text>
        </g>

        {/* === Rotating outer deco ring === */}
        <circle
          cx={cx} cy={cy}
          r="52"
          fill="none"
          stroke="rgba(255,255,255,0.10)"
          strokeWidth="1"
          strokeDasharray="3 9"
          style={{ animation: "hub-spin 18s linear infinite", transformOrigin: `${cx}px ${cy}px` }}
        />
      </svg>
    </div>
  );
}
