"use client";

import { useEffect, useState } from "react";

// Hub-and-spoke node data
const SPOKE_NODES = [
  {
    label: "Database",
    angle: -90,
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5">
        <ellipse cx="12" cy="5" rx="9" ry="3" />
        <path d="M3 5v14c0 1.66 4.03 3 9 3s9-1.34 9-3V5" />
        <path d="M3 12c0 1.66 4.03 3 9 3s9-1.34 9-3" />
      </svg>
    ),
  },
  {
    label: "REST API",
    angle: -18,
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5">
        <path d="M4 6h16M4 12h10M4 18h7" />
        <polyline points="15 15 18 18 21 15" />
        <line x1="18" y1="9" x2="18" y2="18" />
      </svg>
    ),
  },
  {
    label: "Cloud",
    angle: 54,
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5">
        <path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z" />
      </svg>
    ),
  },
  {
    label: "Files",
    angle: 126,
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5">
        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
        <polyline points="14 2 14 8 20 8" />
        <line x1="8" y1="13" x2="16" y2="13" />
        <line x1="8" y1="17" x2="13" y2="17" />
      </svg>
    ),
  },
  {
    label: "Tools",
    angle: 198,
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" className="w-5 h-5">
        <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z" />
      </svg>
    ),
  },
];

const TAKEAWAYS = [
  {
    label: "Scalability",
    subtitle: "N+M not N×M",
    color: "#2C5FDE",
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" className="w-7 h-7">
        <polyline points="22 7 13.5 15.5 8.5 10.5 2 17" />
        <polyline points="16 7 22 7 22 13" />
      </svg>
    ),
  },
  {
    label: "Interoperability",
    subtitle: "Write once, run anywhere",
    color: "#1A4AC4",
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" className="w-7 h-7">
        <circle cx="12" cy="12" r="3" />
        <path d="M12 1v4M12 19v4M4.22 4.22l2.83 2.83M16.95 16.95l2.83 2.83M1 12h4M19 12h4M4.22 19.78l2.83-2.83M16.95 7.05l2.83-2.83" />
      </svg>
    ),
  },
  {
    label: "Security",
    subtitle: "Local-first, controlled access",
    color: "#0F3BA8",
    icon: (
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" className="w-7 h-7">
        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
      </svg>
    ),
  },
];

function toRad(deg: number) {
  return (deg * Math.PI) / 180;
}

export function Slide8Summary() {
  const [revealed, setRevealed] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setRevealed(true), 120);
    return () => clearTimeout(timer);
  }, []);

  // SVG layout constants (viewBox 0 0 320 200)
  const cx = 160;
  const cy = 90;
  const spokeR = 76; // distance from hub center to spoke node center
  const hubR = 30;
  const nodeR = 22;

  return (
    <div className="flex flex-col h-full">
      {/* Slide number watermark */}
      <div
        style={{
          position: "absolute",
          top: "1rem",
          left: "1.5rem",
          fontSize: "3.5rem",
          fontWeight: 700,
          color: "rgba(255,255,255,0.06)",
          lineHeight: 1,
          userSelect: "none",
          pointerEvents: "none",
        }}
      >
        08
      </div>

      {/* Title row */}
      <div style={{ marginBottom: "0.5rem" }}>
        <h2
          style={{
            fontSize: "clamp(1.1rem, 2.5vw, 1.75rem)",
            fontWeight: 700,
            color: "#fff",
            lineHeight: 1.2,
          }}
        >
          The Path Forward
        </h2>
        <p style={{ color: "rgba(255,255,255,0.65)", fontSize: "clamp(0.7rem, 1.4vw, 0.9rem)", marginTop: "0.15rem" }}>
          MCP: From APIs to AI-Native Ecosystems
        </p>
      </div>

      {/* Main content area */}
      <div
        style={{
          flex: 1,
          display: "flex",
          flexDirection: "row",
          alignItems: "center",
          gap: "clamp(1rem, 3vw, 2.5rem)",
          minHeight: 0,
        }}
      >
        {/* Hub-and-Spoke diagram */}
        <div
          style={{
            flex: "0 0 auto",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <svg
            viewBox="0 0 320 200"
            style={{ width: "clamp(200px, 38vw, 340px)", height: "auto" }}
            aria-label="Hub-and-spoke diagram showing MCP at center connected to Database, REST API, Cloud, Files, and Tools"
          >
            <defs>
              <radialGradient id="hubGrad" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor="#4A7FFF" />
                <stop offset="100%" stopColor="#1A4AC4" />
              </radialGradient>
              <filter id="glow" x="-40%" y="-40%" width="180%" height="180%">
                <feGaussianBlur stdDeviation="3" result="blur" />
                <feMerge>
                  <feMergeNode in="blur" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
            </defs>

            {/* Spoke lines */}
            {SPOKE_NODES.map((node, i) => {
              const rad = toRad(node.angle);
              const x2 = cx + Math.cos(rad) * (spokeR - nodeR);
              const y2 = cy + Math.sin(rad) * (spokeR - nodeR);
              const x1 = cx + Math.cos(rad) * (hubR + 2);
              const y1 = cy + Math.sin(rad) * (hubR + 2);
              return (
                <line
                  key={node.label}
                  x1={x1}
                  y1={y1}
                  x2={x2}
                  y2={y2}
                  stroke="rgba(255,255,255,0.25)"
                  strokeWidth="1.5"
                  strokeDasharray="4 3"
                  style={{
                    opacity: revealed ? 1 : 0,
                    transition: `opacity 0.4s ease ${0.15 + i * 0.08}s`,
                  }}
                />
              );
            })}

            {/* Spoke nodes */}
            {SPOKE_NODES.map((node, i) => {
              const rad = toRad(node.angle);
              const nx = cx + Math.cos(rad) * spokeR;
              const ny = cy + Math.sin(rad) * spokeR;
              // Label offset to avoid diagram edges
              const lx = cx + Math.cos(rad) * (spokeR + nodeR + 4);
              const ly = cy + Math.sin(rad) * (spokeR + nodeR + 4);
              return (
                <g
                  key={node.label}
                  style={{
                    opacity: revealed ? 1 : 0,
                    transition: `opacity 0.45s ease ${0.2 + i * 0.09}s`,
                  }}
                >
                  {/* Node circle */}
                  <circle
                    cx={nx}
                    cy={ny}
                    r={nodeR}
                    fill="rgba(255,255,255,0.10)"
                    stroke="rgba(255,255,255,0.35)"
                    strokeWidth="1.5"
                  />
                  {/* Icon via foreignObject */}
                  <foreignObject
                    x={nx - 10}
                    y={ny - 10}
                    width={20}
                    height={20}
                    style={{ color: "#fff", overflow: "visible" }}
                  >
                    <div
                      style={{
                        width: 20,
                        height: 20,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        color: "#fff",
                      }}
                    >
                      {node.icon}
                    </div>
                  </foreignObject>
                  {/* Label */}
                  <text
                    x={lx}
                    y={ly}
                    textAnchor="middle"
                    dominantBaseline="middle"
                    fill="rgba(255,255,255,0.75)"
                    fontSize="8"
                    fontWeight="500"
                    style={{ fontFamily: "inherit" }}
                  >
                    {node.label}
                  </text>
                </g>
              );
            })}

            {/* Hub circle */}
            <circle
              cx={cx}
              cy={cy}
              r={hubR + 6}
              fill="rgba(255,255,255,0.07)"
              stroke="rgba(255,255,255,0.18)"
              strokeWidth="1"
            />
            <circle
              cx={cx}
              cy={cy}
              r={hubR}
              fill="url(#hubGrad)"
              filter="url(#glow)"
              style={{
                opacity: revealed ? 1 : 0,
                transition: "opacity 0.5s ease 0.05s",
              }}
            />
            {/* Hub label */}
            <text
              x={cx}
              y={cy - 5}
              textAnchor="middle"
              dominantBaseline="middle"
              fill="#fff"
              fontSize="11"
              fontWeight="700"
              style={{ fontFamily: "inherit", letterSpacing: "0.05em" }}
            >
              MCP
            </text>
            <text
              x={cx}
              y={cy + 9}
              textAnchor="middle"
              dominantBaseline="middle"
              fill="rgba(255,255,255,0.65)"
              fontSize="6.5"
              style={{ fontFamily: "inherit" }}
            >
              Protocol Hub
            </text>
          </svg>
        </div>

        {/* Right: key takeaways list */}
        <div
          style={{
            flex: 1,
            display: "flex",
            flexDirection: "column",
            gap: "clamp(0.35rem, 0.9vw, 0.65rem)",
            minWidth: 0,
          }}
        >
          {[
            { label: "Standardized integration layer", detail: "Eliminates N×M complexity with a universal protocol" },
            { label: "Dynamic tool discovery", detail: "AI agents find and use capabilities at runtime" },
            { label: "Stateful conversations", detail: "Context persists across multi-turn interactions" },
            { label: "Security-first design", detail: "Local execution, controlled access, data stays put" },
            { label: "Growing ecosystem", detail: "Claude, Cursor, Codeium & more adopting MCP" },
          ].map((item, i) => (
            <div
              key={item.label}
              style={{
                display: "flex",
                alignItems: "flex-start",
                gap: "0.6rem",
                opacity: revealed ? 1 : 0,
                transform: revealed ? "translateX(0)" : "translateX(12px)",
                transition: `opacity 0.4s ease ${0.3 + i * 0.07}s, transform 0.4s ease ${0.3 + i * 0.07}s`,
              }}
            >
              <div
                style={{
                  width: 6,
                  height: 6,
                  borderRadius: "50%",
                  background: "#4A7FFF",
                  flexShrink: 0,
                  marginTop: "0.35rem",
                }}
              />
              <div>
                <span
                  style={{
                    color: "#fff",
                    fontWeight: 600,
                    fontSize: "clamp(0.62rem, 1.2vw, 0.8rem)",
                  }}
                >
                  {item.label}
                </span>
                <span
                  style={{
                    color: "rgba(255,255,255,0.55)",
                    fontSize: "clamp(0.55rem, 1vw, 0.7rem)",
                    marginLeft: "0.35rem",
                  }}
                >
                  — {item.detail}
                </span>
              </div>
            </div>
          ))}

          {/* Big picture quote */}
          <div
            style={{
              marginTop: "clamp(0.3rem, 0.8vw, 0.6rem)",
              padding: "clamp(0.35rem, 0.8vw, 0.55rem) clamp(0.5rem, 1.2vw, 0.8rem)",
              borderLeft: "3px solid rgba(255,255,255,0.4)",
              background: "rgba(255,255,255,0.06)",
              borderRadius: "0 6px 6px 0",
              opacity: revealed ? 1 : 0,
              transition: "opacity 0.5s ease 0.7s",
            }}
          >
            <p
              style={{
                color: "rgba(255,255,255,0.8)",
                fontSize: "clamp(0.6rem, 1.1vw, 0.75rem)",
                fontStyle: "italic",
                lineHeight: 1.45,
                margin: 0,
              }}
            >
              "Just as USB-C unified device connectivity, MCP is unifying AI-tool integration — enabling more capable agents and faster development cycles."
            </p>
          </div>
        </div>
      </div>

      {/* Bottom: Three takeaway icon cards */}
      <div
        style={{
          display: "flex",
          gap: "clamp(0.5rem, 1.5vw, 1rem)",
          marginTop: "clamp(0.4rem, 1vw, 0.75rem)",
        }}
      >
        {TAKEAWAYS.map((t, i) => (
          <div
            key={t.label}
            style={{
              flex: 1,
              display: "flex",
              alignItems: "center",
              gap: "0.6rem",
              background: "rgba(255,255,255,0.08)",
              border: "1px solid rgba(255,255,255,0.18)",
              borderRadius: 8,
              padding: "clamp(0.35rem, 0.9vw, 0.6rem) clamp(0.5rem, 1.2vw, 0.75rem)",
              opacity: revealed ? 1 : 0,
              transform: revealed ? "translateY(0)" : "translateY(10px)",
              transition: `opacity 0.45s ease ${0.55 + i * 0.1}s, transform 0.45s ease ${0.55 + i * 0.1}s`,
              cursor: "default",
            }}
          >
            <div
              style={{
                width: "clamp(28px, 4vw, 38px)",
                height: "clamp(28px, 4vw, 38px)",
                borderRadius: 8,
                background: t.color,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                color: "#fff",
                flexShrink: 0,
              }}
            >
              {t.icon}
            </div>
            <div>
              <div
                style={{
                  color: "#fff",
                  fontWeight: 700,
                  fontSize: "clamp(0.62rem, 1.15vw, 0.78rem)",
                  lineHeight: 1.2,
                }}
              >
                {t.label}
              </div>
              <div
                style={{
                  color: "rgba(255,255,255,0.55)",
                  fontSize: "clamp(0.52rem, 0.95vw, 0.66rem)",
                  lineHeight: 1.3,
                }}
              >
                {t.subtitle}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
