"use client";

import { AdvantagesIconGrid } from "./advantages-icon-grid";

export function Slide6Advantages() {
  return (
    <div className="flex flex-col h-full">
      {/* Slide Number watermark */}
      <div className="text-6xl font-bold text-foreground/5 absolute top-4 left-6 pointer-events-none select-none">
        06
      </div>

      {/* Title */}
      <h2 className="text-2xl md:text-3xl font-bold text-primary mb-1">
        Why MCP Matters
      </h2>

      {/* Subtitle */}
      <p className="text-sm text-muted-foreground mb-3">
        Strategic advantages for AI integration that compound over time
      </p>

      {/* Advantages Cards */}
      <div className="flex-1 flex items-center min-h-0">
        <AdvantagesIconGrid />
      </div>
    </div>
  );
}
