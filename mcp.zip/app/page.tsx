import { SlideDeck } from "@/components/slide-deck/slide-deck";
import { SlideContainer } from "@/components/slide-deck/slide-container";
import { Slide1TitleSlide } from "@/components/slides/slide-1-title";
import { Slide2ProblemStatement } from "@/components/slides/slide-2-problem";
import { Slide3Architecture } from "@/components/slides/slide-3-architecture";
import { Slide4Workflow } from "@/components/slides/slide-4-workflow";
import { Slide5Comparison } from "@/components/slides/slide-5-comparison";
import { Slide6Advantages } from "@/components/slides/slide-6-advantages";
import { Slide7Implementation } from "@/components/slides/slide-7-implementation";
import { Slide8Summary } from "@/components/slides/slide-8-summary";

export default function Home() {
  // Define which slides use primary (royal blue) vs light background
  const slideVariants: ("primary" | "light")[] = [
    "primary", // Slide 1: Title
    "light",   // Slide 2: Problem
    "light",   // Slide 3: Architecture
    "light",   // Slide 4: Workflow
    "light",   // Slide 5: Comparison
    "light",   // Slide 6: Advantages
    "light",   // Slide 7: Implementation
    "primary", // Slide 8: Summary
  ];

  return (
    <main>
      <SlideDeck slideVariants={slideVariants}>
        {/* Slide 1: Title */}
        <SlideContainer variant="primary">
          <Slide1TitleSlide />
        </SlideContainer>

        {/* Slide 2: Problem Statement */}
        <SlideContainer variant="light">
          <Slide2ProblemStatement />
        </SlideContainer>

        {/* Slide 3: MCP Architecture */}
        <SlideContainer variant="light">
          <Slide3Architecture />
        </SlideContainer>

        {/* Slide 4: Communication Workflow */}
        <SlideContainer variant="light">
          <Slide4Workflow />
        </SlideContainer>

        {/* Slide 5: MCP vs REST APIs */}
        <SlideContainer variant="light">
          <Slide5Comparison />
        </SlideContainer>

        {/* Slide 6: Key Advantages */}
        <SlideContainer variant="light">
          <Slide6Advantages />
        </SlideContainer>

        {/* Slide 7: Practical Implementation */}
        <SlideContainer variant="light">
          <Slide7Implementation />
        </SlideContainer>

        {/* Slide 8: Final Summary */}
        <SlideContainer variant="primary">
          <Slide8Summary />
        </SlideContainer>
      </SlideDeck>
    </main>
  );
}
