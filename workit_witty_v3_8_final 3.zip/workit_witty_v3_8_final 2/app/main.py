from fastapi import FastAPI, Query
from pydantic import BaseModel
from typing import List, Dict
from app.services import ai_agent
from app.services import jira_client

app = FastAPI(title="Workit (Witty) - AI Workplace Assistant")

class JiraRequest(BaseModel):
    jira_ids: List[str]

class PeopleRequest(BaseModel):
    people: List[str]

class TextRequest(BaseModel):
    text: str

class MeetingDetails(BaseModel):
    attendees: str
    title: str
    date: str
    time: str
    duration: str

@app.post("/summarize_jira")
def summarize_jira(req: JiraRequest):
    summary = ai_agent.summarize_text(req.jira_ids)
    return summary

@app.post("/extract_meeting")
def extract_meeting(req: TextRequest):
    details = ai_agent.extract_meeting_details(req.text)
    return details

@app.post("/generate_ics")
def generate_ics(details: MeetingDetails):
    ics_content = ai_agent.generate_ics_file(details.dict())
    return {"ics_content": ics_content}

@app.get("/summarize_emails_by_date")
def summarize_emails_by_date(date: str = Query(..., description="Date in YYYY-MM-DD format")):
    result = ai_agent.summarize_emails_by_date(date)
    return result

@app.post("/closed_tasks_by_people")
def closed_tasks_by_people(req: PeopleRequest):
    result = jira_client.get_closed_tasks_by_people(req.people)
    return result

@app.get("/issue_counts_by_status")
def issue_counts_by_status():
    result = jira_client.get_issue_counts_by_status()
    return result


@app.get("/tasks_by_people")
def tasks_by_people(people: str):
    people_list = [p.strip().lower() for p in people.split(",")]
    matching_tasks = []
    # Assuming MOCK_JIRA_ISSUES is defined elsewhere or will be passed/fetched
    # For now, it's missing from the provided context for main.py
    # This part might need adjustment based on how MOCK_JIRA_ISSUES is handled
    # in the complete application.
    # for issue in MOCK_JIRA_ISSUES:
    #     assignee = issue.get("assignee", "").lower()
    #     if assignee in people_list:
    #         matching_tasks.append({
    #             "key": issue["key"],
    #             "summary": issue["summary"],
    #             "status": issue["status"],
    #             "assignee": issue["assignee"]
    #         })
    return matching_tasks