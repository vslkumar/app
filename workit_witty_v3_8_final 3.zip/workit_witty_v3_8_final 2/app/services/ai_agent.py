import random
from app.services.email_client import get_mock_emails_by_date
import re
from datetime import datetime, timedelta

statuses = ["To Do", "In Progress", "Done"]
key_actions_templates = [
    "Initial analysis is pending.",
    "Engineering team is actively working on this item.",
    "Issue completed and deployed to production.",
    "Currently under review by QA team.",
    "Blocked by dependency on another team."
]
assignees = ["John Doe", "Jane Smith", "Alice Johnson", "Bob Martin", "TBD"]
reporters = ["John Doe", "Jane Smith", "Alice Johnson", "Bob Martin", "TBD"]

def summarize_text(jira_ids: list) -> list:
    results = []
    for jira_id in jira_ids:
        story = f"""### {jira_id}

**Summary:** This is a mocked summary for {jira_id}.
**Status:** {random.choice(statuses)}
**Key Actions:** {random.choice(key_actions_templates)}
**Assignee:** {random.choice(assignees)}
**Reporter:** {random.choice(reporters)}

---
"""
        results.append(story)
    return results

def extract_meeting_details(text: str) -> dict:
    attendees = re.search(r"(?:with|to)\s+([A-Za-z0-9\s,]+)", text)
    attendees_list = attendees.group(1).strip() if attendees else "Attendees TBD"

    time_match = re.search(r"at\s+(\d{1,2}(?::\d{2})?\s*(?:am|pm|AM|PM)?)", text)
    time_str = time_match.group(1).replace(" ", "") if time_match else "9:00AM"

    duration_match = re.search(r"for\s+(\d+)\s*(mins|minutes|hr|hours)", text)
    duration_minutes = 30
    if duration_match:
        value = int(duration_match.group(1))
        unit = duration_match.group(2).lower()
        if unit in ["hr", "hours"]:
            duration_minutes = value * 60
        else:
            duration_minutes = value

    # Assuming current date if not specified
    today = datetime.now().strftime("%Y-%m-%d")

    # Simple title for now, can be enhanced with AI
    title = f"Meeting with {attendees_list.split(',')[0].strip()}" if attendees_list != "Attendees TBD" else "Scheduled Meeting"

    return {
        "attendees": attendees_list,
        "title": title,
        "date": today,
        "time": time_str,
        "duration": f"{duration_minutes} minutes"
    }

def generate_ics_file(meeting_details: dict) -> str:
    title = meeting_details.get("title", "Meeting")
    start_time_str = f"{meeting_details['date']} {meeting_details['time']}"
    duration_minutes_str = meeting_details.get("duration", "30 minutes").replace(" minutes", "").strip()
    duration_minutes = int(duration_minutes_str)

    try:
        start_dt = datetime.strptime(start_time_str, "%Y-%m-%d %I:%M%p")
    except ValueError:
        try:
            start_dt = datetime.strptime(start_time_str, "%Y-%m-%d %I%p")
        except ValueError:
            start_dt = datetime.now().replace(hour=9, minute=0, second=0, microsecond=0) # Default to 9 AM today

    end_dt = start_dt + timedelta(minutes=duration_minutes)

    # Format for ICS
    dtstamp = datetime.now().strftime("%Y%m%dT%H%M%SZ")
    dtstart = start_dt.strftime("%Y%m%dT%H%M%S")
    dtend = end_dt.strftime("%Y%m%dT%H%M%S")
    summary = title
    description = f"Attendees: {meeting_details.get('attendees', 'N/A')}\nDuration: {meeting_details.get('duration', 'N/A')}"

    ics_content = f"""BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Workit (Witty)//AI Workplace Assistant//EN
BEGIN:VEVENT
UID:{datetime.now().strftime("%Y%m%d%H%M%S")}-{"".join(random.choices("0123456789abcdef", k=10))}@workit.witty
DTSTAMP:{dtstamp}Z
DTSTART:{dtstart}
DTEND:{dtend}
SUMMARY:{summary}
DESCRIPTION:{description}
END:VEVENT
END:VCALENDAR"""
    return ics_content

def summarize_emails_by_date(date: str, user: str = "vishal.kr@example.com") -> list:
    emails = get_mock_emails_by_date(date)

    categories = {
        "@mentioned": [],
        "Important": [],
        "Prod P1": []
    }
    todo_list = []

    for email in emails:
        cat = email.get("category", "Uncategorized")
        if cat in categories:
            categories[cat].append(email)
        if cat in ["Important", "Prod P1"]:
            todo_list.append(f"Follow up on '{email['subject']}'")

    story_parts = []

    # Greeting
    story_parts.append(f"👋 Hello, {user}!\nToday’s email summary for **{date}**:\n---\n")

    for cat, emails_in_cat in categories.items():
        if emails_in_cat:
            story_parts.append(f"### {cat} Emails\n\n")
            for email in emails_in_cat:
                story_parts.append(f"- **{email['subject']}**\n  \"{email['summary']}\"\n")
            story_parts.append("---\n")

    # TODO list
    if todo_list:
        story_parts.append("### TODO List for today\n")
        for task in todo_list:
            story_parts.append(f"- {task}\n")
        story_parts.append("---\n")

    return story_parts