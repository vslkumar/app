
import random

mock_jira_issues = [
    {
        "id": "JIRA-100",
        "type": "Bug",
        "summary": "Mocked Jira issue summary 0",
        "status": "Resolved",
        "assignee": "Bob Martin",
        "reporter": "John Doe"
    },
    {
        "id": "JIRA-101",
        "type": "Story",
        "summary": "Mocked Jira issue summary 1",
        "status": "In Progress",
        "assignee": "Bob Martin",
        "reporter": "Alice Johnson"
    },
    {
        "id": "JIRA-102",
        "type": "Story",
        "summary": "Mocked Jira issue summary 2",
        "status": "Unassigned",
        "assignee": "John Doe",
        "reporter": "John Doe"
    },
    {
        "id": "JIRA-103",
        "type": "Story",
        "summary": "Mocked Jira issue summary 3",
        "status": "Unassigned",
        "assignee": "Bob Martin",
        "reporter": "Alice Johnson"
    },
    {
        "id": "JIRA-104",
        "type": "Bug",
        "summary": "Mocked Jira issue summary 4",
        "status": "Unassigned",
        "assignee": "Alice Johnson",
        "reporter": "John Doe"
    },
    {
        "id": "JIRA-105",
        "type": "Story",
        "summary": "Mocked Jira issue summary 5",
        "status": "Unassigned",
        "assignee": "TBD",
        "reporter": "John Doe"
    },
    {
        "id": "JIRA-106",
        "type": "Bug",
        "summary": "Mocked Jira issue summary 6",
        "status": "Unassigned",
        "assignee": "John Doe",
        "reporter": "TBD"
    },
    {
        "id": "JIRA-107",
        "type": "Story",
        "summary": "Mocked Jira issue summary 7",
        "status": "Ready for Review",
        "assignee": "John Doe",
        "reporter": "TBD"
    },
    {
        "id": "JIRA-108",
        "type": "Story",
        "summary": "Mocked Jira issue summary 8",
        "status": "New",
        "assignee": "Alice Johnson",
        "reporter": "John Doe"
    },
    {
        "id": "JIRA-109",
        "type": "Story",
        "summary": "Mocked Jira issue summary 9",
        "status": "Ready for Review",
        "assignee": "TBD",
        "reporter": "Alice Johnson"
    },
    {
        "id": "JIRA-110",
        "type": "Bug",
        "summary": "Mocked Jira issue summary 10",
        "status": "Unassigned",
        "assignee": "TBD",
        "reporter": "Jane Smith"
    },
    {
        "id": "JIRA-111",
        "type": "Story",
        "summary": "Mocked Jira issue summary 11",
        "status": "Ready for Review",
        "assignee": "Alice Johnson",
        "reporter": "Jane Smith"
    },
    {
        "id": "JIRA-112",
        "type": "Story",
        "summary": "Mocked Jira issue summary 12",
        "status": "Ready for Review",
        "assignee": "Jane Smith",
        "reporter": "Jane Smith"
    },
    {
        "id": "JIRA-113",
        "type": "Bug",
        "summary": "Mocked Jira issue summary 13",
        "status": "Ready for Review",
        "assignee": "TBD",
        "reporter": "Alice Johnson"
    },
    {
        "id": "JIRA-114",
        "type": "Bug",
        "summary": "Mocked Jira issue summary 14",
        "status": "Closed",
        "assignee": "Jane Smith",
        "reporter": "Jane Smith"
    },
    {
        "id": "JIRA-115",
        "type": "Bug",
        "summary": "Mocked Jira issue summary 15",
        "status": "Unassigned",
        "assignee": "Jane Smith",
        "reporter": "John Doe"
    },
    {
        "id": "JIRA-116",
        "type": "Bug",
        "summary": "Mocked Jira issue summary 16",
        "status": "In Progress",
        "assignee": "TBD",
        "reporter": "Alice Johnson"
    },
    {
        "id": "JIRA-117",
        "type": "Story",
        "summary": "Mocked Jira issue summary 17",
        "status": "Ready for Review",
        "assignee": "TBD",
        "reporter": "Alice Johnson"
    },
    {
        "id": "JIRA-118",
        "type": "Story",
        "summary": "Mocked Jira issue summary 18",
        "status": "New",
        "assignee": "Bob Martin",
        "reporter": "Bob Martin"
    },
    {
        "id": "JIRA-119",
        "type": "Story",
        "summary": "Mocked Jira issue summary 19",
        "status": "Under Refinement",
        "assignee": "Jane Smith",
        "reporter": "TBD"
    },
    {
        "id": "JIRA-120",
        "type": "Bug",
        "summary": "Mocked Jira issue summary 20",
        "status": "Resolved",
        "assignee": "Alice Johnson",
        "reporter": "Alice Johnson"
    },
    {
        "id": "JIRA-121",
        "type": "Bug",
        "summary": "Mocked Jira issue summary 21",
        "status": "Closed",
        "assignee": "Jane Smith",
        "reporter": "John Doe"
    },
    {
        "id": "JIRA-122",
        "type": "Story",
        "summary": "Mocked Jira issue summary 22",
        "status": "Ready for Review",
        "assignee": "Bob Martin",
        "reporter": "Alice Johnson"
    },
    {
        "id": "JIRA-123",
        "type": "Story",
        "summary": "Mocked Jira issue summary 23",
        "status": "Under Refinement",
        "assignee": "John Doe",
        "reporter": "TBD"
    },
    {
        "id": "JIRA-124",
        "type": "Bug",
        "summary": "Mocked Jira issue summary 24",
        "status": "Closed",
        "assignee": "John Doe",
        "reporter": "Bob Martin"
    },
    {
        "id": "JIRA-125",
        "type": "Bug",
        "summary": "Mocked Jira issue summary 25",
        "status": "Closed",
        "assignee": "Bob Martin",
        "reporter": "TBD"
    },
    {
        "id": "JIRA-126",
        "type": "Bug",
        "summary": "Mocked Jira issue summary 26",
        "status": "Ready for Review",
        "assignee": "Alice Johnson",
        "reporter": "John Doe"
    },
    {
        "id": "JIRA-127",
        "type": "Story",
        "summary": "Mocked Jira issue summary 27",
        "status": "Unassigned",
        "assignee": "Alice Johnson",
        "reporter": "Alice Johnson"
    },
    {
        "id": "JIRA-128",
        "type": "Bug",
        "summary": "Mocked Jira issue summary 28",
        "status": "Under Refinement",
        "assignee": "TBD",
        "reporter": "Alice Johnson"
    },
    {
        "id": "JIRA-129",
        "type": "Story",
        "summary": "Mocked Jira issue summary 29",
        "status": "Closed",
        "assignee": "John Doe",
        "reporter": "TBD"
    },
    {
        "id": "JIRA-130",
        "type": "Bug",
        "summary": "Mocked Jira issue summary 30",
        "status": "Resolved",
        "assignee": "Alice Johnson",
        "reporter": "Jane Smith"
    },
    {
        "id": "JIRA-131",
        "type": "Story",
        "summary": "Mocked Jira issue summary 31",
        "status": "Under Refinement",
        "assignee": "Bob Martin",
        "reporter": "TBD"
    },
    {
        "id": "JIRA-132",
        "type": "Bug",
        "summary": "Mocked Jira issue summary 32",
        "status": "Closed",
        "assignee": "Bob Martin",
        "reporter": "Jane Smith"
    },
    {
        "id": "JIRA-133",
        "type": "Bug",
        "summary": "Mocked Jira issue summary 33",
        "status": "Closed",
        "assignee": "Jane Smith",
        "reporter": "Jane Smith"
    },
    {
        "id": "JIRA-134",
        "type": "Bug",
        "summary": "Mocked Jira issue summary 34",
        "status": "New",
        "assignee": "Alice Johnson",
        "reporter": "Alice Johnson"
    },
    {
        "id": "JIRA-135",
        "type": "Bug",
        "summary": "Mocked Jira issue summary 35",
        "status": "Ready for Review",
        "assignee": "Bob Martin",
        "reporter": "Bob Martin"
    },
    {
        "id": "JIRA-136",
        "type": "Story",
        "summary": "Mocked Jira issue summary 36",
        "status": "Closed",
        "assignee": "Alice Johnson",
        "reporter": "Jane Smith"
    },
    {
        "id": "JIRA-137",
        "type": "Bug",
        "summary": "Mocked Jira issue summary 37",
        "status": "Unassigned",
        "assignee": "John Doe",
        "reporter": "Alice Johnson"
    },
    {
        "id": "JIRA-138",
        "type": "Bug",
        "summary": "Mocked Jira issue summary 38",
        "status": "Resolved",
        "assignee": "TBD",
        "reporter": "John Doe"
    },
    {
        "id": "JIRA-139",
        "type": "Bug",
        "summary": "Mocked Jira issue summary 39",
        "status": "Resolved",
        "assignee": "John Doe",
        "reporter": "Alice Johnson"
    },
    {
        "id": "JIRA-140",
        "type": "Bug",
        "summary": "Mocked Jira issue summary 40",
        "status": "Unassigned",
        "assignee": "Jane Smith",
        "reporter": "TBD"
    },
    {
        "id": "JIRA-141",
        "type": "Story",
        "summary": "Mocked Jira issue summary 41",
        "status": "Unassigned",
        "assignee": "John Doe",
        "reporter": "TBD"
    },
    {
        "id": "JIRA-142",
        "type": "Bug",
        "summary": "Mocked Jira issue summary 42",
        "status": "Under Refinement",
        "assignee": "Alice Johnson",
        "reporter": "TBD"
    },
    {
        "id": "JIRA-143",
        "type": "Bug",
        "summary": "Mocked Jira issue summary 43",
        "status": "In Progress",
        "assignee": "Bob Martin",
        "reporter": "Bob Martin"
    },
    {
        "id": "JIRA-144",
        "type": "Story",
        "summary": "Mocked Jira issue summary 44",
        "status": "Closed",
        "assignee": "Alice Johnson",
        "reporter": "John Doe"
    },
    {
        "id": "JIRA-145",
        "type": "Bug",
        "summary": "Mocked Jira issue summary 45",
        "status": "Resolved",
        "assignee": "TBD",
        "reporter": "Jane Smith"
    },
    {
        "id": "JIRA-146",
        "type": "Story",
        "summary": "Mocked Jira issue summary 46",
        "status": "Under Refinement",
        "assignee": "Alice Johnson",
        "reporter": "Bob Martin"
    },
    {
        "id": "JIRA-147",
        "type": "Bug",
        "summary": "Mocked Jira issue summary 47",
        "status": "In Progress",
        "assignee": "Bob Martin",
        "reporter": "Jane Smith"
    },
    {
        "id": "JIRA-148",
        "type": "Story",
        "summary": "Mocked Jira issue summary 48",
        "status": "In Progress",
        "assignee": "Alice Johnson",
        "reporter": "John Doe"
    },
    {
        "id": "JIRA-149",
        "type": "Bug",
        "summary": "Mocked Jira issue summary 49",
        "status": "Resolved",
        "assignee": "John Doe",
        "reporter": "John Doe"
    }
]

def get_mock_jira_issues_by_ids(jira_ids: list):
    result = []
    for jira_id in jira_ids:
        match = next((issue for issue in mock_jira_issues if issue["id"] == jira_id.strip()), None)
        if match:
            result.append(match)
    return result

def get_closed_tasks_by_people(people: list):
    result = [
        issue for issue in mock_jira_issues
        if issue["assignee"] in people and issue["status"] in ["Closed", "Resolved"]
    ]
    return result

def get_issue_counts_by_status():
    counts = {"Stories": {}, "Bugs": {}}
    statuses = ["New", "In Progress", "Ready for Review", "Closed", "Unassigned", "Under Refinement", "Resolved"]
    for t in ["Story", "Bug"]:
        for s in statuses:
            counts["Stories" if t == "Story" else "Bugs"][s] = sum(
                1 for issue in mock_jira_issues if issue["type"] == t and issue["status"] == s
            )
    return counts
