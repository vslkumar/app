
mock_email_data = {
    "2025-06-01": [
        {
            "subject": "Team Recognition #0",
            "from": "bob@example.com",
            "summary": "Final approval needed before release.",
            "category": "Prod P1"
        },
        {
            "subject": "Team Offsite Planning #1",
            "from": "dave@example.com",
            "summary": "FYI: No action needed.",
            "category": "@mentioned"
        },
        {
            "subject": "Weekly Status Update #2",
            "from": "grace@example.com",
            "summary": "Meeting notes from yesterday's call.",
            "category": "@mentioned"
        },
        {
            "subject": "Feature Request #3",
            "from": "bob@example.com",
            "summary": "Final approval needed before release.",
            "category": "Uncategorized"
        },
        {
            "subject": "Client Escalation #4",
            "from": "dave@example.com",
            "summary": "Please prioritize this issue.",
            "category": "Uncategorized"
        },
        {
            "subject": "Incident Report #5",
            "from": "dave@example.com",
            "summary": "FYI: No action needed.",
            "category": "Uncategorized"
        },
        {
            "subject": "Quarterly Business Review #6",
            "from": "bob@example.com",
            "summary": "Urgent review required.",
            "category": "Uncategorized"
        },
        {
            "subject": "Security Advisory #7",
            "from": "eve@example.com",
            "summary": "FYI: No action needed.",
            "category": "Uncategorized"
        },
        {
            "subject": "Marketing Campaign Approval #8",
            "from": "eve@example.com",
            "summary": "Meeting notes from yesterday's call.",
            "category": "Uncategorized"
        },
        {
            "subject": "Legal Compliance Update #9",
            "from": "ivan@example.com",
            "summary": "Urgent review required.",
            "category": "Uncategorized"
        },
        {
            "subject": "Feature Request #10",
            "from": "eve@example.com",
            "summary": "Meeting notes from yesterday's call.",
            "category": "Uncategorized"
        },
        {
            "subject": "Quarterly Business Review #11",
            "from": "ivan@example.com",
            "summary": "See updated project timeline.",
            "category": "@mentioned"
        },
        {
            "subject": "Weekly Status Update #12",
            "from": "ivan@example.com",
            "summary": "Meeting notes from yesterday's call.",
            "category": "@mentioned"
        },
        {
            "subject": "General Inquiry #13",
            "from": "judy@example.com",
            "summary": "Urgent review required.",
            "category": "Uncategorized"
        },
        {
            "subject": "Policy Update #14",
            "from": "heidi@example.com",
            "summary": "Meeting notes from yesterday's call.",
            "category": "Uncategorized"
        },
        {
            "subject": "Incident Report #15",
            "from": "frank@example.com",
            "summary": "Meeting notes from yesterday's call.",
            "category": "Uncategorized"
        }
    ],
    "2025-06-02": [
        {
            "subject": "General Inquiry #0",
            "from": "bob@example.com",
            "summary": "FYI: No action needed.",
            "category": "@mentioned"
        },
        {
            "subject": "Legal Compliance Update #1",
            "from": "dave@example.com",
            "summary": "Follow up with the client on this matter.",
            "category": "Uncategorized"
        },
        {
            "subject": "Project Launch Plan #2",
            "from": "judy@example.com",
            "summary": "Action required on the following items.",
            "category": "@mentioned"
        },
        {
            "subject": "Policy Update #3",
            "from": "eve@example.com",
            "summary": "Please prioritize this issue.",
            "category": "@mentioned"
        },
        {
            "subject": "Customer Feedback Report #4",
            "from": "frank@example.com",
            "summary": "Meeting notes from yesterday's call.",
            "category": "Prod P1"
        },
        {
            "subject": "New Hire Onboarding #5",
            "from": "dave@example.com",
            "summary": "Please review the attached document.",
            "category": "Prod P1"
        },
        {
            "subject": "Bug Fix Confirmation #6",
            "from": "dave@example.com",
            "summary": "Final approval needed before release.",
            "category": "Prod P1"
        },
        {
            "subject": "Project Launch Plan #7",
            "from": "frank@example.com",
            "summary": "Final approval needed before release.",
            "category": "@mentioned"
        },
        {
            "subject": "Marketing Campaign Approval #8",
            "from": "alice@example.com",
            "summary": "FYI: No action needed.",
            "category": "Uncategorized"
        },
        {
            "subject": "New Hire Onboarding #9",
            "from": "bob@example.com",
            "summary": "FYI: No action needed.",
            "category": "Uncategorized"
        },
        {
            "subject": "Policy Update #10",
            "from": "bob@example.com",
            "summary": "See updated project timeline.",
            "category": "@mentioned"
        },
        {
            "subject": "New Hire Onboarding #11",
            "from": "alice@example.com",
            "summary": "Customer feedback summary attached.",
            "category": "Prod P1"
        },
        {
            "subject": "IT Maintenance Notification #12",
            "from": "eve@example.com",
            "summary": "Meeting notes from yesterday's call.",
            "category": "Important"
        },
        {
            "subject": "Security Advisory #13",
            "from": "carol@example.com",
            "summary": "Please review the attached document.",
            "category": "Uncategorized"
        },
        {
            "subject": "New Hire Onboarding #14",
            "from": "ivan@example.com",
            "summary": "Urgent review required.",
            "category": "Important"
        },
        {
            "subject": "Production Outage #15",
            "from": "eve@example.com",
            "summary": "Please prioritize this issue.",
            "category": "Uncategorized"
        }
    ],
    "2025-06-03": [
        {
            "subject": "Vendor Contract Review #0",
            "from": "judy@example.com",
            "summary": "Action required on the following items.",
            "category": "Uncategorized"
        },
        {
            "subject": "General Inquiry #1",
            "from": "bob@example.com",
            "summary": "Final approval needed before release.",
            "category": "Uncategorized"
        },
        {
            "subject": "IT Maintenance Notification #2",
            "from": "eve@example.com",
            "summary": "Action required on the following items.",
            "category": "Prod P1"
        },
        {
            "subject": "Project Launch Plan #3",
            "from": "alice@example.com",
            "summary": "Customer feedback summary attached.",
            "category": "Prod P1"
        },
        {
            "subject": "Policy Update #4",
            "from": "judy@example.com",
            "summary": "Urgent review required.",
            "category": "Uncategorized"
        },
        {
            "subject": "Incident Report #5",
            "from": "heidi@example.com",
            "summary": "Customer feedback summary attached.",
            "category": "Important"
        },
        {
            "subject": "Legal Compliance Update #6",
            "from": "ivan@example.com",
            "summary": "FYI: No action needed.",
            "category": "Uncategorized"
        },
        {
            "subject": "Performance Review Reminder #7",
            "from": "heidi@example.com",
            "summary": "FYI: No action needed.",
            "category": "Prod P1"
        },
        {
            "subject": "Legal Compliance Update #8",
            "from": "judy@example.com",
            "summary": "Follow up with the client on this matter.",
            "category": "Prod P1"
        },
        {
            "subject": "Weekly Status Update #9",
            "from": "dave@example.com",
            "summary": "Customer feedback summary attached.",
            "category": "Uncategorized"
        },
        {
            "subject": "Production Outage #10",
            "from": "heidi@example.com",
            "summary": "Follow up with the client on this matter.",
            "category": "Uncategorized"
        },
        {
            "subject": "General Inquiry #11",
            "from": "dave@example.com",
            "summary": "Final approval needed before release.",
            "category": "Uncategorized"
        },
        {
            "subject": "Security Advisory #12",
            "from": "frank@example.com",
            "summary": "FYI: No action needed.",
            "category": "Uncategorized"
        },
        {
            "subject": "Vendor Contract Review #13",
            "from": "grace@example.com",
            "summary": "Customer feedback summary attached.",
            "category": "Important"
        },
        {
            "subject": "General Inquiry #14",
            "from": "dave@example.com",
            "summary": "Customer feedback summary attached.",
            "category": "@mentioned"
        },
        {
            "subject": "New Hire Onboarding #15",
            "from": "grace@example.com",
            "summary": "FYI: No action needed.",
            "category": "Important"
        }
    ],
    "2025-06-04": [
        {
            "subject": "Weekly Status Update #0",
            "from": "judy@example.com",
            "summary": "Urgent review required.",
            "category": "Uncategorized"
        },
        {
            "subject": "Production Outage #1",
            "from": "dave@example.com",
            "summary": "Please prioritize this issue.",
            "category": "@mentioned"
        },
        {
            "subject": "Policy Update #2",
            "from": "carol@example.com",
            "summary": "Customer feedback summary attached.",
            "category": "Important"
        },
        {
            "subject": "Weekly Status Update #3",
            "from": "alice@example.com",
            "summary": "Meeting notes from yesterday's call.",
            "category": "Uncategorized"
        },
        {
            "subject": "Customer Feedback Report #4",
            "from": "eve@example.com",
            "summary": "Please review the attached document.",
            "category": "Prod P1"
        },
        {
            "subject": "Bug Fix Confirmation #5",
            "from": "judy@example.com",
            "summary": "Action required on the following items.",
            "category": "Uncategorized"
        },
        {
            "subject": "Vendor Contract Review #6",
            "from": "carol@example.com",
            "summary": "Action required on the following items.",
            "category": "Important"
        },
        {
            "subject": "Client Escalation #7",
            "from": "eve@example.com",
            "summary": "Final approval needed before release.",
            "category": "Uncategorized"
        },
        {
            "subject": "Quarterly Business Review #8",
            "from": "bob@example.com",
            "summary": "FYI: No action needed.",
            "category": "Uncategorized"
        },
        {
            "subject": "Incident Report #9",
            "from": "carol@example.com",
            "summary": "Please prioritize this issue.",
            "category": "Important"
        },
        {
            "subject": "Quarterly Business Review #10",
            "from": "bob@example.com",
            "summary": "Follow up with the client on this matter.",
            "category": "Uncategorized"
        },
        {
            "subject": "Policy Update #11",
            "from": "alice@example.com",
            "summary": "FYI: No action needed.",
            "category": "Important"
        },
        {
            "subject": "Project Launch Plan #12",
            "from": "judy@example.com",
            "summary": "Urgent review required.",
            "category": "@mentioned"
        },
        {
            "subject": "Quarterly Business Review #13",
            "from": "bob@example.com",
            "summary": "Meeting notes from yesterday's call.",
            "category": "@mentioned"
        },
        {
            "subject": "Customer Feedback Report #14",
            "from": "bob@example.com",
            "summary": "Please prioritize this issue.",
            "category": "@mentioned"
        },
        {
            "subject": "Production Outage #15",
            "from": "heidi@example.com",
            "summary": "Meeting notes from yesterday's call.",
            "category": "Uncategorized"
        }
    ],
    "2025-06-05": [
        {
            "subject": "Security Advisory #0",
            "from": "dave@example.com",
            "summary": "FYI: No action needed.",
            "category": "Prod P1"
        },
        {
            "subject": "General Inquiry #1",
            "from": "heidi@example.com",
            "summary": "Action required on the following items.",
            "category": "Uncategorized"
        },
        {
            "subject": "Quarterly Business Review #2",
            "from": "alice@example.com",
            "summary": "Follow up with the client on this matter.",
            "category": "Prod P1"
        },
        {
            "subject": "Team Offsite Planning #3",
            "from": "carol@example.com",
            "summary": "See updated project timeline.",
            "category": "@mentioned"
        },
        {
            "subject": "Bug Fix Confirmation #4",
            "from": "heidi@example.com",
            "summary": "Action required on the following items.",
            "category": "Uncategorized"
        },
        {
            "subject": "Security Advisory #5",
            "from": "frank@example.com",
            "summary": "Urgent review required.",
            "category": "Prod P1"
        },
        {
            "subject": "Performance Review Reminder #6",
            "from": "ivan@example.com",
            "summary": "Meeting notes from yesterday's call.",
            "category": "Uncategorized"
        },
        {
            "subject": "New Hire Onboarding #7",
            "from": "eve@example.com",
            "summary": "Meeting notes from yesterday's call.",
            "category": "@mentioned"
        },
        {
            "subject": "Legal Compliance Update #8",
            "from": "carol@example.com",
            "summary": "FYI: No action needed.",
            "category": "Uncategorized"
        },
        {
            "subject": "Incident Report #9",
            "from": "judy@example.com",
            "summary": "Customer feedback summary attached.",
            "category": "Uncategorized"
        },
        {
            "subject": "Quarterly Business Review #10",
            "from": "grace@example.com",
            "summary": "Please review the attached document.",
            "category": "Important"
        },
        {
            "subject": "Marketing Campaign Approval #11",
            "from": "eve@example.com",
            "summary": "Final approval needed before release.",
            "category": "Uncategorized"
        },
        {
            "subject": "Customer Feedback Report #12",
            "from": "alice@example.com",
            "summary": "Customer feedback summary attached.",
            "category": "Important"
        },
        {
            "subject": "Legal Compliance Update #13",
            "from": "ivan@example.com",
            "summary": "Action required on the following items.",
            "category": "Important"
        },
        {
            "subject": "Policy Update #14",
            "from": "dave@example.com",
            "summary": "Final approval needed before release.",
            "category": "Important"
        },
        {
            "subject": "Production Outage #15",
            "from": "heidi@example.com",
            "summary": "Urgent review required.",
            "category": "Important"
        }
    ],
    "2025-06-06": [
        {
            "subject": "Client Escalation #0",
            "from": "carol@example.com",
            "summary": "Please review the attached document.",
            "category": "Uncategorized"
        },
        {
            "subject": "Team Offsite Planning #1",
            "from": "ivan@example.com",
            "summary": "See updated project timeline.",
            "category": "@mentioned"
        },
        {
            "subject": "Bug Fix Confirmation #2",
            "from": "eve@example.com",
            "summary": "FYI: No action needed.",
            "category": "Uncategorized"
        },
        {
            "subject": "General Inquiry #3",
            "from": "alice@example.com",
            "summary": "Meeting notes from yesterday's call.",
            "category": "Uncategorized"
        },
        {
            "subject": "Project Launch Plan #4",
            "from": "heidi@example.com",
            "summary": "Final approval needed before release.",
            "category": "Important"
        },
        {
            "subject": "Policy Update #5",
            "from": "ivan@example.com",
            "summary": "Please prioritize this issue.",
            "category": "Important"
        },
        {
            "subject": "Performance Review Reminder #6",
            "from": "bob@example.com",
            "summary": "Urgent review required.",
            "category": "Uncategorized"
        },
        {
            "subject": "Legal Compliance Update #7",
            "from": "grace@example.com",
            "summary": "Follow up with the client on this matter.",
            "category": "Prod P1"
        },
        {
            "subject": "Project Launch Plan #8",
            "from": "judy@example.com",
            "summary": "Urgent review required.",
            "category": "@mentioned"
        },
        {
            "subject": "Team Recognition #9",
            "from": "frank@example.com",
            "summary": "Urgent review required.",
            "category": "Prod P1"
        },
        {
            "subject": "Client Escalation #10",
            "from": "eve@example.com",
            "summary": "Urgent review required.",
            "category": "Uncategorized"
        },
        {
            "subject": "Policy Update #11",
            "from": "judy@example.com",
            "summary": "See updated project timeline.",
            "category": "Important"
        },
        {
            "subject": "Vendor Contract Review #12",
            "from": "carol@example.com",
            "summary": "FYI: No action needed.",
            "category": "Uncategorized"
        },
        {
            "subject": "Marketing Campaign Approval #13",
            "from": "eve@example.com",
            "summary": "FYI: No action needed.",
            "category": "Uncategorized"
        },
        {
            "subject": "Feature Request #14",
            "from": "judy@example.com",
            "summary": "Urgent review required.",
            "category": "Important"
        },
        {
            "subject": "Team Recognition #15",
            "from": "dave@example.com",
            "summary": "See updated project timeline.",
            "category": "Important"
        }
    ],
    "2025-06-07": [
        {
            "subject": "Security Advisory #0",
            "from": "bob@example.com",
            "summary": "Meeting notes from yesterday's call.",
            "category": "Uncategorized"
        },
        {
            "subject": "Customer Feedback Report #1",
            "from": "judy@example.com",
            "summary": "FYI: No action needed.",
            "category": "Important"
        },
        {
            "subject": "Incident Report #2",
            "from": "dave@example.com",
            "summary": "Please prioritize this issue.",
            "category": "Important"
        },
        {
            "subject": "Customer Feedback Report #3",
            "from": "bob@example.com",
            "summary": "Please review the attached document.",
            "category": "Uncategorized"
        },
        {
            "subject": "Quarterly Business Review #4",
            "from": "frank@example.com",
            "summary": "FYI: No action needed.",
            "category": "Uncategorized"
        },
        {
            "subject": "Marketing Campaign Approval #5",
            "from": "carol@example.com",
            "summary": "FYI: No action needed.",
            "category": "Prod P1"
        },
        {
            "subject": "Legal Compliance Update #6",
            "from": "grace@example.com",
            "summary": "Please prioritize this issue.",
            "category": "Uncategorized"
        },
        {
            "subject": "Team Offsite Planning #7",
            "from": "dave@example.com",
            "summary": "See updated project timeline.",
            "category": "@mentioned"
        },
        {
            "subject": "Marketing Campaign Approval #8",
            "from": "eve@example.com",
            "summary": "Please prioritize this issue.",
            "category": "Uncategorized"
        },
        {
            "subject": "Client Escalation #9",
            "from": "carol@example.com",
            "summary": "See updated project timeline.",
            "category": "Uncategorized"
        },
        {
            "subject": "Production Outage #10",
            "from": "carol@example.com",
            "summary": "Action required on the following items.",
            "category": "Prod P1"
        },
        {
            "subject": "Client Escalation #11",
            "from": "eve@example.com",
            "summary": "Action required on the following items.",
            "category": "Uncategorized"
        },
        {
            "subject": "Marketing Campaign Approval #12",
            "from": "carol@example.com",
            "summary": "Action required on the following items.",
            "category": "Uncategorized"
        },
        {
            "subject": "Quarterly Business Review #13",
            "from": "dave@example.com",
            "summary": "Final approval needed before release.",
            "category": "Important"
        },
        {
            "subject": "Performance Review Reminder #14",
            "from": "alice@example.com",
            "summary": "Follow up with the client on this matter.",
            "category": "Important"
        },
        {
            "subject": "Policy Update #15",
            "from": "carol@example.com",
            "summary": "Urgent review required.",
            "category": "Uncategorized"
        }
    ],
    "2025-06-08": [
        {
            "subject": "Project Launch Plan #0",
            "from": "alice@example.com",
            "summary": "Please review the attached document.",
            "category": "@mentioned"
        },
        {
            "subject": "Vendor Contract Review #1",
            "from": "alice@example.com",
            "summary": "Follow up with the client on this matter.",
            "category": "Prod P1"
        },
        {
            "subject": "Feature Request #2",
            "from": "alice@example.com",
            "summary": "Meeting notes from yesterday's call.",
            "category": "Important"
        },
        {
            "subject": "Project Launch Plan #3",
            "from": "alice@example.com",
            "summary": "Please prioritize this issue.",
            "category": "Uncategorized"
        },
        {
            "subject": "Quarterly Business Review #4",
            "from": "judy@example.com",
            "summary": "Customer feedback summary attached.",
            "category": "Uncategorized"
        },
        {
            "subject": "Bug Fix Confirmation #5",
            "from": "alice@example.com",
            "summary": "FYI: No action needed.",
            "category": "Prod P1"
        },
        {
            "subject": "Quarterly Business Review #6",
            "from": "carol@example.com",
            "summary": "Final approval needed before release.",
            "category": "@mentioned"
        },
        {
            "subject": "New Hire Onboarding #7",
            "from": "carol@example.com",
            "summary": "Please review the attached document.",
            "category": "Uncategorized"
        },
        {
            "subject": "Team Offsite Planning #8",
            "from": "heidi@example.com",
            "summary": "Please review the attached document.",
            "category": "Important"
        },
        {
            "subject": "Feature Request #9",
            "from": "alice@example.com",
            "summary": "Action required on the following items.",
            "category": "@mentioned"
        },
        {
            "subject": "Weekly Status Update #10",
            "from": "judy@example.com",
            "summary": "Urgent review required.",
            "category": "Prod P1"
        },
        {
            "subject": "Bug Fix Confirmation #11",
            "from": "frank@example.com",
            "summary": "Urgent review required.",
            "category": "@mentioned"
        },
        {
            "subject": "Team Recognition #12",
            "from": "alice@example.com",
            "summary": "Please review the attached document.",
            "category": "@mentioned"
        },
        {
            "subject": "Feature Request #13",
            "from": "alice@example.com",
            "summary": "Urgent review required.",
            "category": "Uncategorized"
        },
        {
            "subject": "Vendor Contract Review #14",
            "from": "heidi@example.com",
            "summary": "Meeting notes from yesterday's call.",
            "category": "Uncategorized"
        },
        {
            "subject": "Policy Update #15",
            "from": "heidi@example.com",
            "summary": "Follow up with the client on this matter.",
            "category": "Important"
        }
    ],
    "2025-06-09": [
        {
            "subject": "IT Maintenance Notification #0",
            "from": "ivan@example.com",
            "summary": "Follow up with the client on this matter.",
            "category": "@mentioned"
        },
        {
            "subject": "Security Advisory #1",
            "from": "alice@example.com",
            "summary": "See updated project timeline.",
            "category": "Uncategorized"
        },
        {
            "subject": "Legal Compliance Update #2",
            "from": "bob@example.com",
            "summary": "FYI: No action needed.",
            "category": "Important"
        },
        {
            "subject": "Client Escalation #3",
            "from": "alice@example.com",
            "summary": "Follow up with the client on this matter.",
            "category": "Important"
        },
        {
            "subject": "New Hire Onboarding #4",
            "from": "grace@example.com",
            "summary": "Final approval needed before release.",
            "category": "Important"
        },
        {
            "subject": "Feature Request #5",
            "from": "frank@example.com",
            "summary": "Meeting notes from yesterday's call.",
            "category": "Important"
        },
        {
            "subject": "Team Offsite Planning #6",
            "from": "ivan@example.com",
            "summary": "Meeting notes from yesterday's call.",
            "category": "Uncategorized"
        },
        {
            "subject": "New Hire Onboarding #7",
            "from": "alice@example.com",
            "summary": "Follow up with the client on this matter.",
            "category": "Uncategorized"
        },
        {
            "subject": "Vendor Contract Review #8",
            "from": "ivan@example.com",
            "summary": "Action required on the following items.",
            "category": "Prod P1"
        },
        {
            "subject": "Vendor Contract Review #9",
            "from": "grace@example.com",
            "summary": "Urgent review required.",
            "category": "Uncategorized"
        },
        {
            "subject": "Bug Fix Confirmation #10",
            "from": "bob@example.com",
            "summary": "See updated project timeline.",
            "category": "Uncategorized"
        },
        {
            "subject": "Client Escalation #11",
            "from": "carol@example.com",
            "summary": "See updated project timeline.",
            "category": "Important"
        },
        {
            "subject": "Client Escalation #12",
            "from": "dave@example.com",
            "summary": "Final approval needed before release.",
            "category": "Uncategorized"
        },
        {
            "subject": "Security Advisory #13",
            "from": "bob@example.com",
            "summary": "Action required on the following items.",
            "category": "@mentioned"
        },
        {
            "subject": "Policy Update #14",
            "from": "judy@example.com",
            "summary": "Customer feedback summary attached.",
            "category": "Uncategorized"
        },
        {
            "subject": "Bug Fix Confirmation #15",
            "from": "grace@example.com",
            "summary": "Urgent review required.",
            "category": "@mentioned"
        }
    ],
    "2025-06-10": [
        {
            "subject": "Security Advisory #0",
            "from": "frank@example.com",
            "summary": "Follow up with the client on this matter.",
            "category": "Uncategorized"
        },
        {
            "subject": "Team Recognition #1",
            "from": "judy@example.com",
            "summary": "Please review the attached document.",
            "category": "Uncategorized"
        },
        {
            "subject": "General Inquiry #2",
            "from": "frank@example.com",
            "summary": "Follow up with the client on this matter.",
            "category": "Uncategorized"
        },
        {
            "subject": "Vendor Contract Review #3",
            "from": "eve@example.com",
            "summary": "Please review the attached document.",
            "category": "Uncategorized"
        },
        {
            "subject": "Project Launch Plan #4",
            "from": "heidi@example.com",
            "summary": "Final approval needed before release.",
            "category": "Important"
        },
        {
            "subject": "Security Advisory #5",
            "from": "dave@example.com",
            "summary": "Action required on the following items.",
            "category": "Uncategorized"
        },
        {
            "subject": "IT Maintenance Notification #6",
            "from": "eve@example.com",
            "summary": "Customer feedback summary attached.",
            "category": "Important"
        },
        {
            "subject": "Security Advisory #7",
            "from": "ivan@example.com",
            "summary": "Urgent review required.",
            "category": "Uncategorized"
        },
        {
            "subject": "Performance Review Reminder #8",
            "from": "bob@example.com",
            "summary": "Follow up with the client on this matter.",
            "category": "Uncategorized"
        },
        {
            "subject": "Customer Feedback Report #9",
            "from": "frank@example.com",
            "summary": "Action required on the following items.",
            "category": "Uncategorized"
        },
        {
            "subject": "General Inquiry #10",
            "from": "dave@example.com",
            "summary": "Customer feedback summary attached.",
            "category": "Uncategorized"
        },
        {
            "subject": "Production Outage #11",
            "from": "heidi@example.com",
            "summary": "Urgent review required.",
            "category": "Uncategorized"
        },
        {
            "subject": "Quarterly Business Review #12",
            "from": "ivan@example.com",
            "summary": "Urgent review required.",
            "category": "@mentioned"
        },
        {
            "subject": "Policy Update #13",
            "from": "bob@example.com",
            "summary": "Action required on the following items.",
            "category": "Uncategorized"
        },
        {
            "subject": "New Hire Onboarding #14",
            "from": "judy@example.com",
            "summary": "Please prioritize this issue.",
            "category": "Uncategorized"
        },
        {
            "subject": "Client Escalation #15",
            "from": "ivan@example.com",
            "summary": "Customer feedback summary attached.",
            "category": "Uncategorized"
        }
    ],
    "2025-06-11": [
        {
            "subject": "Security Advisory #0",
            "from": "carol@example.com",
            "summary": "See updated project timeline.",
            "category": "@mentioned"
        },
        {
            "subject": "Bug Fix Confirmation #1",
            "from": "carol@example.com",
            "summary": "Customer feedback summary attached.",
            "category": "Uncategorized"
        },
        {
            "subject": "Bug Fix Confirmation #2",
            "from": "ivan@example.com",
            "summary": "Please prioritize this issue.",
            "category": "Prod P1"
        },
        {
            "subject": "Security Advisory #3",
            "from": "dave@example.com",
            "summary": "Urgent review required.",
            "category": "Prod P1"
        },
        {
            "subject": "Team Offsite Planning #4",
            "from": "alice@example.com",
            "summary": "Please review the attached document.",
            "category": "Important"
        },
        {
            "subject": "Security Advisory #5",
            "from": "dave@example.com",
            "summary": "Customer feedback summary attached.",
            "category": "@mentioned"
        },
        {
            "subject": "Weekly Status Update #6",
            "from": "ivan@example.com",
            "summary": "Action required on the following items.",
            "category": "Uncategorized"
        },
        {
            "subject": "Marketing Campaign Approval #7",
            "from": "eve@example.com",
            "summary": "Final approval needed before release.",
            "category": "Uncategorized"
        },
        {
            "subject": "Incident Report #8",
            "from": "alice@example.com",
            "summary": "Action required on the following items.",
            "category": "Uncategorized"
        },
        {
            "subject": "New Hire Onboarding #9",
            "from": "dave@example.com",
            "summary": "Please prioritize this issue.",
            "category": "Prod P1"
        },
        {
            "subject": "New Hire Onboarding #10",
            "from": "dave@example.com",
            "summary": "Please review the attached document.",
            "category": "Uncategorized"
        },
        {
            "subject": "Performance Review Reminder #11",
            "from": "frank@example.com",
            "summary": "See updated project timeline.",
            "category": "Uncategorized"
        },
        {
            "subject": "Feature Request #12",
            "from": "dave@example.com",
            "summary": "Customer feedback summary attached.",
            "category": "Uncategorized"
        },
        {
            "subject": "New Hire Onboarding #13",
            "from": "bob@example.com",
            "summary": "Urgent review required.",
            "category": "Prod P1"
        },
        {
            "subject": "Legal Compliance Update #14",
            "from": "dave@example.com",
            "summary": "Final approval needed before release.",
            "category": "@mentioned"
        },
        {
            "subject": "Team Recognition #15",
            "from": "frank@example.com",
            "summary": "See updated project timeline.",
            "category": "Important"
        }
    ],
    "2025-06-12": [
        {
            "subject": "Incident Report #0",
            "from": "heidi@example.com",
            "summary": "Please prioritize this issue.",
            "category": "Uncategorized"
        },
        {
            "subject": "New Hire Onboarding #1",
            "from": "dave@example.com",
            "summary": "Follow up with the client on this matter.",
            "category": "@mentioned"
        },
        {
            "subject": "Security Advisory #2",
            "from": "carol@example.com",
            "summary": "Urgent review required.",
            "category": "Uncategorized"
        },
        {
            "subject": "Project Launch Plan #3",
            "from": "dave@example.com",
            "summary": "Action required on the following items.",
            "category": "Uncategorized"
        },
        {
            "subject": "Feature Request #4",
            "from": "carol@example.com",
            "summary": "Please prioritize this issue.",
            "category": "Uncategorized"
        },
        {
            "subject": "Policy Update #5",
            "from": "ivan@example.com",
            "summary": "Customer feedback summary attached.",
            "category": "Important"
        },
        {
            "subject": "Policy Update #6",
            "from": "carol@example.com",
            "summary": "Please prioritize this issue.",
            "category": "Prod P1"
        },
        {
            "subject": "IT Maintenance Notification #7",
            "from": "dave@example.com",
            "summary": "Final approval needed before release.",
            "category": "Prod P1"
        },
        {
            "subject": "New Hire Onboarding #8",
            "from": "alice@example.com",
            "summary": "Final approval needed before release.",
            "category": "Uncategorized"
        },
        {
            "subject": "Project Launch Plan #9",
            "from": "bob@example.com",
            "summary": "Meeting notes from yesterday's call.",
            "category": "Uncategorized"
        },
        {
            "subject": "Weekly Status Update #10",
            "from": "eve@example.com",
            "summary": "See updated project timeline.",
            "category": "Uncategorized"
        },
        {
            "subject": "Production Outage #11",
            "from": "eve@example.com",
            "summary": "Final approval needed before release.",
            "category": "Uncategorized"
        },
        {
            "subject": "Bug Fix Confirmation #12",
            "from": "ivan@example.com",
            "summary": "Meeting notes from yesterday's call.",
            "category": "Important"
        },
        {
            "subject": "Client Escalation #13",
            "from": "carol@example.com",
            "summary": "FYI: No action needed.",
            "category": "Uncategorized"
        },
        {
            "subject": "Weekly Status Update #14",
            "from": "bob@example.com",
            "summary": "Please review the attached document.",
            "category": "Uncategorized"
        },
        {
            "subject": "Client Escalation #15",
            "from": "frank@example.com",
            "summary": "Meeting notes from yesterday's call.",
            "category": "Important"
        }
    ],
    "2025-06-13": [
        {
            "subject": "Security Advisory #0",
            "from": "eve@example.com",
            "summary": "Meeting notes from yesterday's call.",
            "category": "Uncategorized"
        },
        {
            "subject": "Bug Fix Confirmation #1",
            "from": "grace@example.com",
            "summary": "See updated project timeline.",
            "category": "Uncategorized"
        },
        {
            "subject": "Marketing Campaign Approval #2",
            "from": "judy@example.com",
            "summary": "Meeting notes from yesterday's call.",
            "category": "Uncategorized"
        },
        {
            "subject": "Quarterly Business Review #3",
            "from": "eve@example.com",
            "summary": "Please prioritize this issue.",
            "category": "Uncategorized"
        },
        {
            "subject": "Policy Update #4",
            "from": "frank@example.com",
            "summary": "Action required on the following items.",
            "category": "Prod P1"
        },
        {
            "subject": "Customer Feedback Report #5",
            "from": "grace@example.com",
            "summary": "Final approval needed before release.",
            "category": "Uncategorized"
        },
        {
            "subject": "Weekly Status Update #6",
            "from": "alice@example.com",
            "summary": "Please review the attached document.",
            "category": "Important"
        },
        {
            "subject": "Security Advisory #7",
            "from": "alice@example.com",
            "summary": "Meeting notes from yesterday's call.",
            "category": "Uncategorized"
        },
        {
            "subject": "Performance Review Reminder #8",
            "from": "bob@example.com",
            "summary": "Customer feedback summary attached.",
            "category": "@mentioned"
        },
        {
            "subject": "Incident Report #9",
            "from": "eve@example.com",
            "summary": "Action required on the following items.",
            "category": "@mentioned"
        },
        {
            "subject": "Marketing Campaign Approval #10",
            "from": "heidi@example.com",
            "summary": "Final approval needed before release.",
            "category": "Uncategorized"
        },
        {
            "subject": "New Hire Onboarding #11",
            "from": "ivan@example.com",
            "summary": "Urgent review required.",
            "category": "Important"
        },
        {
            "subject": "Feature Request #12",
            "from": "judy@example.com",
            "summary": "See updated project timeline.",
            "category": "Important"
        },
        {
            "subject": "Client Escalation #13",
            "from": "bob@example.com",
            "summary": "Urgent review required.",
            "category": "Important"
        },
        {
            "subject": "Policy Update #14",
            "from": "grace@example.com",
            "summary": "Follow up with the client on this matter.",
            "category": "Important"
        },
        {
            "subject": "Team Recognition #15",
            "from": "eve@example.com",
            "summary": "Please prioritize this issue.",
            "category": "Important"
        }
    ],
    "2025-06-14": [
        {
            "subject": "Bug Fix Confirmation #0",
            "from": "dave@example.com",
            "summary": "Action required on the following items.",
            "category": "Uncategorized"
        },
        {
            "subject": "Client Escalation #1",
            "from": "alice@example.com",
            "summary": "Customer feedback summary attached.",
            "category": "@mentioned"
        },
        {
            "subject": "Production Outage #2",
            "from": "alice@example.com",
            "summary": "Customer feedback summary attached.",
            "category": "Uncategorized"
        },
        {
            "subject": "Bug Fix Confirmation #3",
            "from": "frank@example.com",
            "summary": "Meeting notes from yesterday's call.",
            "category": "Important"
        },
        {
            "subject": "Production Outage #4",
            "from": "dave@example.com",
            "summary": "Meeting notes from yesterday's call.",
            "category": "Important"
        },
        {
            "subject": "IT Maintenance Notification #5",
            "from": "frank@example.com",
            "summary": "Customer feedback summary attached.",
            "category": "Uncategorized"
        },
        {
            "subject": "Feature Request #6",
            "from": "dave@example.com",
            "summary": "See updated project timeline.",
            "category": "Important"
        },
        {
            "subject": "Quarterly Business Review #7",
            "from": "bob@example.com",
            "summary": "Urgent review required.",
            "category": "Uncategorized"
        },
        {
            "subject": "Project Launch Plan #8",
            "from": "heidi@example.com",
            "summary": "Please prioritize this issue.",
            "category": "Uncategorized"
        },
        {
            "subject": "Team Offsite Planning #9",
            "from": "heidi@example.com",
            "summary": "FYI: No action needed.",
            "category": "Important"
        },
        {
            "subject": "New Hire Onboarding #10",
            "from": "ivan@example.com",
            "summary": "Urgent review required.",
            "category": "Important"
        },
        {
            "subject": "General Inquiry #11",
            "from": "heidi@example.com",
            "summary": "Customer feedback summary attached.",
            "category": "Uncategorized"
        },
        {
            "subject": "Quarterly Business Review #12",
            "from": "carol@example.com",
            "summary": "Please prioritize this issue.",
            "category": "Important"
        },
        {
            "subject": "Weekly Status Update #13",
            "from": "grace@example.com",
            "summary": "Meeting notes from yesterday's call.",
            "category": "Important"
        },
        {
            "subject": "Customer Feedback Report #14",
            "from": "heidi@example.com",
            "summary": "Meeting notes from yesterday's call.",
            "category": "Uncategorized"
        },
        {
            "subject": "Team Offsite Planning #15",
            "from": "bob@example.com",
            "summary": "Urgent review required.",
            "category": "Uncategorized"
        }
    ],
    "2025-06-15": [
        {
            "subject": "Marketing Campaign Approval #0",
            "from": "frank@example.com",
            "summary": "Customer feedback summary attached.",
            "category": "Uncategorized"
        },
        {
            "subject": "Policy Update #1",
            "from": "alice@example.com",
            "summary": "FYI: No action needed.",
            "category": "Uncategorized"
        },
        {
            "subject": "Team Offsite Planning #2",
            "from": "frank@example.com",
            "summary": "FYI: No action needed.",
            "category": "Uncategorized"
        },
        {
            "subject": "Vendor Contract Review #3",
            "from": "heidi@example.com",
            "summary": "Please prioritize this issue.",
            "category": "Uncategorized"
        },
        {
            "subject": "Performance Review Reminder #4",
            "from": "grace@example.com",
            "summary": "See updated project timeline.",
            "category": "Important"
        },
        {
            "subject": "Vendor Contract Review #5",
            "from": "bob@example.com",
            "summary": "Urgent review required.",
            "category": "Important"
        },
        {
            "subject": "Production Outage #6",
            "from": "eve@example.com",
            "summary": "See updated project timeline.",
            "category": "@mentioned"
        },
        {
            "subject": "Project Launch Plan #7",
            "from": "bob@example.com",
            "summary": "Urgent review required.",
            "category": "Uncategorized"
        },
        {
            "subject": "Bug Fix Confirmation #8",
            "from": "frank@example.com",
            "summary": "Customer feedback summary attached.",
            "category": "Uncategorized"
        },
        {
            "subject": "Client Escalation #9",
            "from": "frank@example.com",
            "summary": "Meeting notes from yesterday's call.",
            "category": "Uncategorized"
        },
        {
            "subject": "Vendor Contract Review #10",
            "from": "carol@example.com",
            "summary": "Urgent review required.",
            "category": "Important"
        },
        {
            "subject": "General Inquiry #11",
            "from": "grace@example.com",
            "summary": "Urgent review required.",
            "category": "Uncategorized"
        },
        {
            "subject": "Team Offsite Planning #12",
            "from": "ivan@example.com",
            "summary": "Customer feedback summary attached.",
            "category": "Uncategorized"
        },
        {
            "subject": "Team Recognition #13",
            "from": "judy@example.com",
            "summary": "Meeting notes from yesterday's call.",
            "category": "Uncategorized"
        },
        {
            "subject": "Performance Review Reminder #14",
            "from": "bob@example.com",
            "summary": "FYI: No action needed.",
            "category": "Prod P1"
        },
        {
            "subject": "Bug Fix Confirmation #15",
            "from": "grace@example.com",
            "summary": "Follow up with the client on this matter.",
            "category": "Uncategorized"
        }
    ]
}

def get_mock_emails_by_date(date: str):
    return mock_email_data.get(date, [])
