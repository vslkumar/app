#!/bin/bash
echo "Starting Workit (Witty) Streamlit UI..."
streamlit run ui/streamlit_app.py
