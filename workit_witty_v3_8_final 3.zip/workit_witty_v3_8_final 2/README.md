
# Workit (Witty) - AI Workplace Assistant v3

## Features
- Sidebar with navigation buttons (tabs UX)
- Jira Issue Summarizer (multiple Jira IDs supported)
- Intelligent Meeting Scheduler (realistic parsed data)
- Email Inbox Assistant (20-30 mocked emails by date)
- Advanced UI polish: sidebar logo, footer

## How to Run

### Backend (FastAPI)
```bash
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

### Frontend (Streamlit)
```bash
streamlit run ui/streamlit_app.py
```


## ✨ Recent Improvements (v3.7)

- **Find All Tasks by People**:  
  Now supports searching for *all tasks* (any status: New, In Progress, Under Refinement, Closed, Resolved) for given assignees.  
  Results are shown as a clean **human-readable table**, not raw JSON.

- **Issue Counts by Status**:  
  Results now displayed as **interactive Bar Chart** and **Pie Chart** in the UI — gives clear visual summary of the current Jira issue state.

