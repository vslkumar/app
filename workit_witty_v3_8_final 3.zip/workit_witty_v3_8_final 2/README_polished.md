
# 🚀 Workit (Witty) - AI Workplace Assistant

**Workit (Witty)** is an AI-powered assistant that helps you manage your day-to-day work tasks by integrating with Jira, your calendar, and your email inbox — with a beautifully simple UI.

Built with **FastAPI** + **Streamlit**, optimized for quick productivity and Hackathon demo.

---

## ✨ Key Features

✅ **Jira Issue Summarizer**  
→ Enter any comma-separated Jira IDs → AI generates *human-readable summaries* in story format → perfect for team updates or standups.

✅ **Meeting Scheduler**  
→ Enter a meeting request in plain English → AI parses and extracts structured meeting details → ready to schedule.

✅ **Email Inbox Assistant**  
→ Select a date → AI summarizes **200+ mock emails** from that date → extracts key tasks → groups emails into categories:

- Emails where you were **@mentioned**
- **Important Emails**
- **Production Priority 1**
- Auto-generated **TODO List for today**

✅ **Polished UI for demo**  
→ Sidebar navigation (tabs UX)  
→ Loading spinners on actions  
→ Beautiful header + footer  
→ One-click start scripts provided

---

## 🏃‍♂️ How to Run

### Backend (FastAPI)

```bash
./start_backend.sh
```

### Frontend (Streamlit UI)

```bash
./start_ui.sh
```

---

## 📝 Example Outputs

### Jira Issue Summarizer (input: `JIRA-1234, JIRA-ABCD`)

---

### JIRA-1234

**Summary:** This is a mocked summary for JIRA-1234.  

**Status:** In Progress  

**Key Actions:** Issue completed and deployed to production.  

**Assignee:** Bob Martin  

**Reporter:** Alice Johnson  

---

### JIRA-ABCD

**Summary:** This is a mocked summary for JIRA-ABCD.  

**Status:** To Do  

**Key Actions:** Engineering team is actively working on this item.  

**Assignee:** Jane Smith  

**Reporter:** John Doe  

---

### Email Inbox Assistant (for date: 2025-06-05)

---

👋 Hello, vishal.kr@example.com!  
Today’s email summary for **2025-06-05**:

---

### @mentioned Emails

- **Project Launch Plan #12**  
  "Please review the attached document."  

---

### Important Emails

- **Customer Feedback Report #22**  
  "Customer feedback summary attached."  

- **Quarterly Business Review #30**  
  "Action required on the following items."  

---

### Production Priority 1 Emails

- **P1: Production Outage #7**  
  "Urgent review required."  

---

### TODO List for today

- Follow up on 'Customer Feedback Report #22'  
- Follow up on 'Quarterly Business Review #30'  
- Follow up on 'P1: Production Outage #7'  

---

## 🎁 Ready for Hackathon Demo

✅ UI is polished → Judges will enjoy using it  
✅ Output is **human friendly** → not raw JSON → great for presentation  
✅ Works out of the box → just run `start_backend.sh` + `start_ui.sh`  
✅ Can easily extend with **real APIs** (Jira, Gmail, Google Calendar) post-Hackathon

---

Built with ❤️ for Hackathons.  
*"Work smarter with Workit (Witty) 🚀"*

---
