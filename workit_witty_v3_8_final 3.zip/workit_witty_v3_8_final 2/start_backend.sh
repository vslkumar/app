#!/bin/bash
echo "Starting Workit (Witty) Backend..."
uvicorn app.main:app --reload --port 8000
