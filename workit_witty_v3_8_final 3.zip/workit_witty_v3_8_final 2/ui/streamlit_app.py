import matplotlib.pyplot as plt

import streamlit as st
import requests
import datetime

# Init session state
if "page" not in st.session_state:
    st.session_state.page = "Jira Issue Summarizer"

# Sidebar nav
st.sidebar.markdown("## 🚀 Workit (Witty)")
st.sidebar.markdown("### AI Workplace Assistant")

if st.sidebar.button("📝 Jira Issue Summarizer"):
    st.session_state.page = "Jira Issue Summarizer"
if st.sidebar.button("📅 Meeting Scheduler"):
    st.session_state.page = "Meeting Scheduler"
if st.sidebar.button("📧 Email Inbox Assistant"):
    st.session_state.page = "Email Inbox Assistant"

# Backend URL
BACKEND_URL = "http://localhost:8000"

# Main Page
st.markdown("<h1 style='color:#4A90E2;'>🤖 Workit (Witty) - AI Workplace Assistant</h1>", unsafe_allow_html=True)

# Pages
if st.session_state.page == "Jira Issue Summarizer":
    st.markdown("### 📝 Jira Issue Summarizer")
    jira_ids_input = st.text_input("Enter comma-separated Jira Issue IDs (e.g., JIRA-100,JIRA-105)")
    if st.button("Summarize Jira Issues"):
        jira_ids_list = [jid.strip() for jid in jira_ids_input.split(",") if jid.strip()]
        with st.spinner("Summarizing Jira Issues..."):
            response = requests.post(f"{BACKEND_URL}/summarize_jira", json={"jira_ids": jira_ids_list})
            st.success("Here is the summarized Jira story:")
            for story in response.json():
                st.markdown(story, unsafe_allow_html=True)

    # Additional Jira Features
    st.markdown("---")
    st.markdown("### 🔍 Find Closed Tasks by People")
    people_input = st.text_input("Enter comma-separated people names (e.g., John Doe,Jane Smith)")
    if st.button("Find Closed Tasks"):
        people_list = [p.strip() for p in people_input.split(",") if p.strip()]
        with st.spinner("Finding closed tasks..."):
            response = requests.post(f"{BACKEND_URL}/closed_tasks_by_people", json={"people": people_list})
            st.success(f"Found {len(response.json())} closed tasks:")
            st.json(response.json())

    st.markdown("---")
    st.markdown("### 📊 Issue Counts by Status")
    if st.button("Get Issue Counts"):
        with st.spinner("Fetching issue counts..."):
            response = requests.get(f"{BACKEND_URL}/issue_counts_by_status")
            st.success("Issue counts:")
            st.json(response.json())

elif st.session_state.page == "Meeting Scheduler":
    st.markdown("### 📅 Intelligent Meeting Scheduler")
    meeting_text = st.text_area("Describe your meeting (e.g., schedule meeting with Sunil at 9 am IST for 30mins):")
    if st.button("Extract Meeting Details"):
        with st.spinner("Extracting meeting details..."):
            response = requests.post(f"{BACKEND_URL}/extract_meeting", json={"text": meeting_text})
            meeting_details = response.json()
            st.success("Meeting details extracted:")
            st.json(meeting_details)

            # Generate and allow download of ICS file
            ics_response = requests.post(f"{BACKEND_URL}/generate_ics", json=meeting_details)
            ics_content = ics_response.json().get("ics_content")

            if ics_content:
                st.markdown(f"Meeting scheduled with {meeting_details.get('attendees', 'the specified participants')}.")
                st.download_button(
                    label="Download Meeting File (.ics)",
                    data=ics_content,
                    file_name=f"{meeting_details.get('title', 'meeting').replace(' ', '_')}.ics",
                    mime="text/calendar",
                )
            else:
                st.error("Failed to generate ICS file.")


elif st.session_state.page == "Email Inbox Assistant":
    st.markdown("### 📧 Email Inbox Assistant")
    date = st.date_input("Select date", value=datetime.date(2025, 6, 5))
    if st.button("Summarize Emails"):
        with st.spinner("Summarizing emails..."):
            response = requests.get(f"{BACKEND_URL}/summarize_emails_by_date", params={"date": date.isoformat()})
            st.success("Here is your personalized email summary:")
            for part in response.json():
                st.markdown(part, unsafe_allow_html=True)

# Footer
st.markdown("---")
st.markdown("<p style='text-align:center;'>© 2025 <b>Workit (Witty)</b> - AI Assistant - Hackathon Edition 🚀</p>", unsafe_allow_html=True)